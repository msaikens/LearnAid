﻿Imports learnAid.Forms.MasterForms

Module GlobalVariables


    Public sch_name As String
    Public sch_id As Integer


End Module
