Namespace Forms.MasterForms
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmOptions
#Region "Windows Form Designer generated code "
        <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
            MyBase.New()
            'This call is required by the Windows Form Designer.
            InitializeComponent()
        End Sub
        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not components Is Nothing Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub
        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer
        Public ToolTip1 As System.Windows.Forms.ToolTip
        Public WithEvents fraSample4 As System.Windows.Forms.GroupBox
        Public WithEvents _picOptions_3 As System.Windows.Forms.Panel
        Public WithEvents fraSample3 As System.Windows.Forms.GroupBox
        Public WithEvents _picOptions_2 As System.Windows.Forms.Panel
        Public WithEvents fraSample2 As System.Windows.Forms.GroupBox
        Public WithEvents _picOptions_1 As System.Windows.Forms.Panel
        Public WithEvents cmdApply As System.Windows.Forms.Button
        Public WithEvents cmdCancel As System.Windows.Forms.Button
        Public WithEvents cmdOK As System.Windows.Forms.Button
        Public WithEvents Label7 As System.Windows.Forms.Label
        Public WithEvents chkShowStartUp As System.Windows.Forms.CheckBox
        Public WithEvents Command5 As System.Windows.Forms.Button
        Public WithEvents txtPluginsPath As System.Windows.Forms.TextBox
        Public WithEvents txtReportsPath As System.Windows.Forms.TextBox
        Public WithEvents Command4 As System.Windows.Forms.Button
        Public WithEvents Command3 As System.Windows.Forms.Button
        Public WithEvents txtConsultantsPath As System.Windows.Forms.TextBox
        Public WithEvents Command2 As System.Windows.Forms.Button
        Public WithEvents txtDataFilesPath As System.Windows.Forms.TextBox
        Public WithEvents Label9 As System.Windows.Forms.Label
        Public WithEvents Label8 As System.Windows.Forms.Label
        Public WithEvents Label6 As System.Windows.Forms.Label
        Public WithEvents Label5 As System.Windows.Forms.Label
        Public WithEvents Frame1 As System.Windows.Forms.GroupBox
        Public WithEvents chkEnableLog As System.Windows.Forms.CheckBox
        Public WithEvents txtCompID As System.Windows.Forms.TextBox
        Public WithEvents _SSTab1_TabPage0 As System.Windows.Forms.TabPage
        Public WithEvents chkBlankPassword As System.Windows.Forms.CheckBox
        Public WithEvents Command1 As System.Windows.Forms.Button
        Public WithEvents txtPassword As System.Windows.Forms.TextBox
        Public WithEvents txtUserID As System.Windows.Forms.TextBox
        Public WithEvents txtDataSource As System.Windows.Forms.TextBox
        Public WithEvents txtDatabase As System.Windows.Forms.TextBox
        Public WithEvents Label4 As System.Windows.Forms.Label
        Public WithEvents Label3 As System.Windows.Forms.Label
        Public WithEvents Label2 As System.Windows.Forms.Label
        Public WithEvents label1 As System.Windows.Forms.Label
        Public WithEvents _SSTab1_TabPage1 As System.Windows.Forms.TabPage
        Public WithEvents SSTab1 As System.Windows.Forms.TabControl
        Public WithEvents picOptions As Microsoft.VisualBasic.Compatibility.VB6.PanelArray
        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOptions))
            Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
            Me._picOptions_3 = New System.Windows.Forms.Panel()
            Me.fraSample4 = New System.Windows.Forms.GroupBox()
            Me._picOptions_2 = New System.Windows.Forms.Panel()
            Me.fraSample3 = New System.Windows.Forms.GroupBox()
            Me._picOptions_1 = New System.Windows.Forms.Panel()
            Me.fraSample2 = New System.Windows.Forms.GroupBox()
            Me.cmdApply = New System.Windows.Forms.Button()
            Me.cmdCancel = New System.Windows.Forms.Button()
            Me.cmdOK = New System.Windows.Forms.Button()
            Me.SSTab1 = New System.Windows.Forms.TabControl()
            Me._SSTab1_TabPage0 = New System.Windows.Forms.TabPage()
            Me.Label7 = New System.Windows.Forms.Label()
            Me.chkShowStartUp = New System.Windows.Forms.CheckBox()
            Me.Frame1 = New System.Windows.Forms.GroupBox()
            Me.Command5 = New System.Windows.Forms.Button()
            Me.txtPluginsPath = New System.Windows.Forms.TextBox()
            Me.txtReportsPath = New System.Windows.Forms.TextBox()
            Me.Command4 = New System.Windows.Forms.Button()
            Me.Command3 = New System.Windows.Forms.Button()
            Me.txtConsultantsPath = New System.Windows.Forms.TextBox()
            Me.Command2 = New System.Windows.Forms.Button()
            Me.txtDataFilesPath = New System.Windows.Forms.TextBox()
            Me.Label9 = New System.Windows.Forms.Label()
            Me.Label8 = New System.Windows.Forms.Label()
            Me.Label6 = New System.Windows.Forms.Label()
            Me.Label5 = New System.Windows.Forms.Label()
            Me.chkEnableLog = New System.Windows.Forms.CheckBox()
            Me.txtCompID = New System.Windows.Forms.TextBox()
            Me._SSTab1_TabPage1 = New System.Windows.Forms.TabPage()
            Me.chkBlankPassword = New System.Windows.Forms.CheckBox()
            Me.Command1 = New System.Windows.Forms.Button()
            Me.txtPassword = New System.Windows.Forms.TextBox()
            Me.txtUserID = New System.Windows.Forms.TextBox()
            Me.txtDataSource = New System.Windows.Forms.TextBox()
            Me.txtDatabase = New System.Windows.Forms.TextBox()
            Me.Label4 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.label1 = New System.Windows.Forms.Label()
            Me.picOptions = New Microsoft.VisualBasic.Compatibility.VB6.PanelArray(Me.components)
            Me._picOptions_3.SuspendLayout()
            Me._picOptions_2.SuspendLayout()
            Me._picOptions_1.SuspendLayout()
            Me.SSTab1.SuspendLayout()
            Me._SSTab1_TabPage0.SuspendLayout()
            Me.Frame1.SuspendLayout()
            Me._SSTab1_TabPage1.SuspendLayout()
            CType(Me.picOptions, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            '_picOptions_3
            '
            Me._picOptions_3.BackColor = System.Drawing.SystemColors.Control
            Me._picOptions_3.Controls.Add(Me.fraSample4)
            Me._picOptions_3.Cursor = System.Windows.Forms.Cursors.Default
            Me._picOptions_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._picOptions_3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.picOptions.SetIndex(Me._picOptions_3, CType(3, Short))
            Me._picOptions_3.Location = New System.Drawing.Point(-1333, 32)
            Me._picOptions_3.Name = "_picOptions_3"
            Me._picOptions_3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._picOptions_3.Size = New System.Drawing.Size(379, 252)
            Me._picOptions_3.TabIndex = 5
            '
            'fraSample4
            '
            Me.fraSample4.BackColor = System.Drawing.SystemColors.Control
            Me.fraSample4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.fraSample4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.fraSample4.Location = New System.Drawing.Point(140, 56)
            Me.fraSample4.Name = "fraSample4"
            Me.fraSample4.Padding = New System.Windows.Forms.Padding(0)
            Me.fraSample4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.fraSample4.Size = New System.Drawing.Size(137, 119)
            Me.fraSample4.TabIndex = 8
            Me.fraSample4.TabStop = False
            Me.fraSample4.Text = "Sample 4"
            '
            '_picOptions_2
            '
            Me._picOptions_2.BackColor = System.Drawing.SystemColors.Control
            Me._picOptions_2.Controls.Add(Me.fraSample3)
            Me._picOptions_2.Cursor = System.Windows.Forms.Cursors.Default
            Me._picOptions_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._picOptions_2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.picOptions.SetIndex(Me._picOptions_2, CType(2, Short))
            Me._picOptions_2.Location = New System.Drawing.Point(-1333, 32)
            Me._picOptions_2.Name = "_picOptions_2"
            Me._picOptions_2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._picOptions_2.Size = New System.Drawing.Size(379, 252)
            Me._picOptions_2.TabIndex = 4
            '
            'fraSample3
            '
            Me.fraSample3.BackColor = System.Drawing.SystemColors.Control
            Me.fraSample3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.fraSample3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.fraSample3.Location = New System.Drawing.Point(103, 45)
            Me.fraSample3.Name = "fraSample3"
            Me.fraSample3.Padding = New System.Windows.Forms.Padding(0)
            Me.fraSample3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.fraSample3.Size = New System.Drawing.Size(137, 119)
            Me.fraSample3.TabIndex = 7
            Me.fraSample3.TabStop = False
            Me.fraSample3.Text = "Sample 3"
            '
            '_picOptions_1
            '
            Me._picOptions_1.BackColor = System.Drawing.SystemColors.Control
            Me._picOptions_1.Controls.Add(Me.fraSample2)
            Me._picOptions_1.Cursor = System.Windows.Forms.Cursors.Default
            Me._picOptions_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._picOptions_1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.picOptions.SetIndex(Me._picOptions_1, CType(1, Short))
            Me._picOptions_1.Location = New System.Drawing.Point(-1333, 32)
            Me._picOptions_1.Name = "_picOptions_1"
            Me._picOptions_1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._picOptions_1.Size = New System.Drawing.Size(379, 252)
            Me._picOptions_1.TabIndex = 3
            '
            'fraSample2
            '
            Me.fraSample2.BackColor = System.Drawing.SystemColors.Control
            Me.fraSample2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.fraSample2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.fraSample2.Location = New System.Drawing.Point(43, 20)
            Me.fraSample2.Name = "fraSample2"
            Me.fraSample2.Padding = New System.Windows.Forms.Padding(0)
            Me.fraSample2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.fraSample2.Size = New System.Drawing.Size(137, 119)
            Me.fraSample2.TabIndex = 6
            Me.fraSample2.TabStop = False
            Me.fraSample2.Text = "Sample 2"
            '
            'cmdApply
            '
            Me.cmdApply.BackColor = System.Drawing.SystemColors.Control
            Me.cmdApply.Cursor = System.Windows.Forms.Cursors.Default
            Me.cmdApply.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.cmdApply.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdApply.Location = New System.Drawing.Point(248, 310)
            Me.cmdApply.Name = "cmdApply"
            Me.cmdApply.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.cmdApply.Size = New System.Drawing.Size(73, 25)
            Me.cmdApply.TabIndex = 2
            Me.cmdApply.Text = "Apply"
            Me.cmdApply.UseVisualStyleBackColor = False
            '
            'cmdCancel
            '
            Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
            Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
            Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdCancel.Location = New System.Drawing.Point(328, 310)
            Me.cmdCancel.Name = "cmdCancel"
            Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.cmdCancel.Size = New System.Drawing.Size(73, 25)
            Me.cmdCancel.TabIndex = 1
            Me.cmdCancel.Text = "Cancel"
            Me.cmdCancel.UseVisualStyleBackColor = False
            '
            'cmdOK
            '
            Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
            Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
            Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdOK.Location = New System.Drawing.Point(168, 310)
            Me.cmdOK.Name = "cmdOK"
            Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.cmdOK.Size = New System.Drawing.Size(73, 25)
            Me.cmdOK.TabIndex = 0
            Me.cmdOK.Text = "OK"
            Me.cmdOK.UseVisualStyleBackColor = False
            '
            'SSTab1
            '
            Me.SSTab1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
            Me.SSTab1.Controls.Add(Me._SSTab1_TabPage0)
            Me.SSTab1.Controls.Add(Me._SSTab1_TabPage1)
            Me.SSTab1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.SSTab1.ItemSize = New System.Drawing.Size(42, 18)
            Me.SSTab1.Location = New System.Drawing.Point(8, 8)
            Me.SSTab1.Name = "SSTab1"
            Me.SSTab1.SelectedIndex = 0
            Me.SSTab1.Size = New System.Drawing.Size(393, 281)
            Me.SSTab1.TabIndex = 9
            '
            '_SSTab1_TabPage0
            '
            Me._SSTab1_TabPage0.Controls.Add(Me.Label7)
            Me._SSTab1_TabPage0.Controls.Add(Me.chkShowStartUp)
            Me._SSTab1_TabPage0.Controls.Add(Me.Frame1)
            Me._SSTab1_TabPage0.Controls.Add(Me.chkEnableLog)
            Me._SSTab1_TabPage0.Controls.Add(Me.txtCompID)
            Me._SSTab1_TabPage0.Location = New System.Drawing.Point(4, 22)
            Me._SSTab1_TabPage0.Name = "_SSTab1_TabPage0"
            Me._SSTab1_TabPage0.Size = New System.Drawing.Size(385, 255)
            Me._SSTab1_TabPage0.TabIndex = 0
            Me._SSTab1_TabPage0.Text = "General"
            '
            'Label7
            '
            Me.Label7.BackColor = System.Drawing.Color.Transparent
            Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label7.Location = New System.Drawing.Point(180, 10)
            Me.Label7.Name = "Label7"
            Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label7.Size = New System.Drawing.Size(65, 17)
            Me.Label7.TabIndex = 29
            Me.Label7.Text = "Computer ID"
            '
            'chkShowStartUp
            '
            Me.chkShowStartUp.BackColor = System.Drawing.SystemColors.Control
            Me.chkShowStartUp.Cursor = System.Windows.Forms.Cursors.Default
            Me.chkShowStartUp.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.chkShowStartUp.ForeColor = System.Drawing.SystemColors.ControlText
            Me.chkShowStartUp.Location = New System.Drawing.Point(28, 12)
            Me.chkShowStartUp.Name = "chkShowStartUp"
            Me.chkShowStartUp.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.chkShowStartUp.Size = New System.Drawing.Size(121, 17)
            Me.chkShowStartUp.TabIndex = 19
            Me.chkShowStartUp.Text = "Show StartUp Page"
            Me.chkShowStartUp.UseVisualStyleBackColor = False
            '
            'Frame1
            '
            Me.Frame1.BackColor = System.Drawing.SystemColors.Control
            Me.Frame1.Controls.Add(Me.Command5)
            Me.Frame1.Controls.Add(Me.txtPluginsPath)
            Me.Frame1.Controls.Add(Me.txtReportsPath)
            Me.Frame1.Controls.Add(Me.Command4)
            Me.Frame1.Controls.Add(Me.Command3)
            Me.Frame1.Controls.Add(Me.txtConsultantsPath)
            Me.Frame1.Controls.Add(Me.Command2)
            Me.Frame1.Controls.Add(Me.txtDataFilesPath)
            Me.Frame1.Controls.Add(Me.Label9)
            Me.Frame1.Controls.Add(Me.Label8)
            Me.Frame1.Controls.Add(Me.Label6)
            Me.Frame1.Controls.Add(Me.Label5)
            Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frame1.Location = New System.Drawing.Point(9, 67)
            Me.Frame1.Name = "Frame1"
            Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
            Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Frame1.Size = New System.Drawing.Size(373, 185)
            Me.Frame1.TabIndex = 20
            Me.Frame1.TabStop = False
            Me.Frame1.Text = "File Paths"
            '
            'Command5
            '
            Me.Command5.BackColor = System.Drawing.SystemColors.Control
            Me.Command5.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command5.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command5.Location = New System.Drawing.Point(304, 160)
            Me.Command5.Name = "Command5"
            Me.Command5.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command5.Size = New System.Drawing.Size(25, 17)
            Me.Command5.TabIndex = 35
            Me.Command5.Text = "..."
            Me.Command5.UseVisualStyleBackColor = False
            '
            'txtPluginsPath
            '
            Me.txtPluginsPath.AcceptsReturn = True
            Me.txtPluginsPath.BackColor = System.Drawing.SystemColors.Window
            Me.txtPluginsPath.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtPluginsPath.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtPluginsPath.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtPluginsPath.Location = New System.Drawing.Point(16, 160)
            Me.txtPluginsPath.MaxLength = 0
            Me.txtPluginsPath.Name = "txtPluginsPath"
            Me.txtPluginsPath.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtPluginsPath.Size = New System.Drawing.Size(281, 19)
            Me.txtPluginsPath.TabIndex = 34
            '
            'txtReportsPath
            '
            Me.txtReportsPath.AcceptsReturn = True
            Me.txtReportsPath.BackColor = System.Drawing.SystemColors.Window
            Me.txtReportsPath.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtReportsPath.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtReportsPath.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtReportsPath.Location = New System.Drawing.Point(16, 120)
            Me.txtReportsPath.MaxLength = 0
            Me.txtReportsPath.Name = "txtReportsPath"
            Me.txtReportsPath.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtReportsPath.Size = New System.Drawing.Size(281, 19)
            Me.txtReportsPath.TabIndex = 32
            '
            'Command4
            '
            Me.Command4.BackColor = System.Drawing.SystemColors.Control
            Me.Command4.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command4.Location = New System.Drawing.Point(304, 120)
            Me.Command4.Name = "Command4"
            Me.Command4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command4.Size = New System.Drawing.Size(25, 17)
            Me.Command4.TabIndex = 31
            Me.Command4.Text = "..."
            Me.Command4.UseVisualStyleBackColor = False
            '
            'Command3
            '
            Me.Command3.BackColor = System.Drawing.SystemColors.Control
            Me.Command3.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command3.Location = New System.Drawing.Point(304, 80)
            Me.Command3.Name = "Command3"
            Me.Command3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command3.Size = New System.Drawing.Size(25, 17)
            Me.Command3.TabIndex = 26
            Me.Command3.Text = "..."
            Me.Command3.UseVisualStyleBackColor = False
            '
            'txtConsultantsPath
            '
            Me.txtConsultantsPath.AcceptsReturn = True
            Me.txtConsultantsPath.BackColor = System.Drawing.SystemColors.Window
            Me.txtConsultantsPath.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtConsultantsPath.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtConsultantsPath.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtConsultantsPath.Location = New System.Drawing.Point(16, 80)
            Me.txtConsultantsPath.MaxLength = 0
            Me.txtConsultantsPath.Name = "txtConsultantsPath"
            Me.txtConsultantsPath.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtConsultantsPath.Size = New System.Drawing.Size(281, 19)
            Me.txtConsultantsPath.TabIndex = 25
            '
            'Command2
            '
            Me.Command2.BackColor = System.Drawing.SystemColors.Control
            Me.Command2.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command2.Location = New System.Drawing.Point(304, 40)
            Me.Command2.Name = "Command2"
            Me.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command2.Size = New System.Drawing.Size(25, 17)
            Me.Command2.TabIndex = 23
            Me.Command2.Text = "..."
            Me.Command2.UseVisualStyleBackColor = False
            '
            'txtDataFilesPath
            '
            Me.txtDataFilesPath.AcceptsReturn = True
            Me.txtDataFilesPath.BackColor = System.Drawing.SystemColors.Window
            Me.txtDataFilesPath.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtDataFilesPath.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtDataFilesPath.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtDataFilesPath.Location = New System.Drawing.Point(16, 40)
            Me.txtDataFilesPath.MaxLength = 0
            Me.txtDataFilesPath.Name = "txtDataFilesPath"
            Me.txtDataFilesPath.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtDataFilesPath.Size = New System.Drawing.Size(281, 19)
            Me.txtDataFilesPath.TabIndex = 22
            '
            'Label9
            '
            Me.Label9.BackColor = System.Drawing.SystemColors.Control
            Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label9.Location = New System.Drawing.Point(16, 144)
            Me.Label9.Name = "Label9"
            Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label9.Size = New System.Drawing.Size(97, 17)
            Me.Label9.TabIndex = 36
            Me.Label9.Text = "Plugins Path"
            '
            'Label8
            '
            Me.Label8.BackColor = System.Drawing.SystemColors.Control
            Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label8.Location = New System.Drawing.Point(16, 104)
            Me.Label8.Name = "Label8"
            Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label8.Size = New System.Drawing.Size(97, 17)
            Me.Label8.TabIndex = 33
            Me.Label8.Text = "Reports Path"
            '
            'Label6
            '
            Me.Label6.BackColor = System.Drawing.SystemColors.Control
            Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label6.Location = New System.Drawing.Point(16, 64)
            Me.Label6.Name = "Label6"
            Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label6.Size = New System.Drawing.Size(169, 17)
            Me.Label6.TabIndex = 24
            Me.Label6.Text = "Consultants report Path"
            '
            'Label5
            '
            Me.Label5.BackColor = System.Drawing.SystemColors.Control
            Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label5.Location = New System.Drawing.Point(16, 24)
            Me.Label5.Name = "Label5"
            Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label5.Size = New System.Drawing.Size(97, 17)
            Me.Label5.TabIndex = 21
            Me.Label5.Text = "Data Files Path"
            '
            'chkEnableLog
            '
            Me.chkEnableLog.BackColor = System.Drawing.SystemColors.Control
            Me.chkEnableLog.Cursor = System.Windows.Forms.Cursors.Default
            Me.chkEnableLog.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.chkEnableLog.ForeColor = System.Drawing.SystemColors.ControlText
            Me.chkEnableLog.Location = New System.Drawing.Point(28, 36)
            Me.chkEnableLog.Name = "chkEnableLog"
            Me.chkEnableLog.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.chkEnableLog.Size = New System.Drawing.Size(129, 17)
            Me.chkEnableLog.TabIndex = 28
            Me.chkEnableLog.Text = "Enable Log Warnings"
            Me.chkEnableLog.UseVisualStyleBackColor = False
            '
            'txtCompID
            '
            Me.txtCompID.AcceptsReturn = True
            Me.txtCompID.BackColor = System.Drawing.SystemColors.Window
            Me.txtCompID.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtCompID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCompID.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtCompID.Location = New System.Drawing.Point(180, 28)
            Me.txtCompID.MaxLength = 0
            Me.txtCompID.Name = "txtCompID"
            Me.txtCompID.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtCompID.Size = New System.Drawing.Size(121, 19)
            Me.txtCompID.TabIndex = 30
            '
            '_SSTab1_TabPage1
            '
            Me._SSTab1_TabPage1.Controls.Add(Me.chkBlankPassword)
            Me._SSTab1_TabPage1.Controls.Add(Me.Command1)
            Me._SSTab1_TabPage1.Controls.Add(Me.txtPassword)
            Me._SSTab1_TabPage1.Controls.Add(Me.txtUserID)
            Me._SSTab1_TabPage1.Controls.Add(Me.txtDataSource)
            Me._SSTab1_TabPage1.Controls.Add(Me.txtDatabase)
            Me._SSTab1_TabPage1.Controls.Add(Me.Label4)
            Me._SSTab1_TabPage1.Controls.Add(Me.Label3)
            Me._SSTab1_TabPage1.Controls.Add(Me.Label2)
            Me._SSTab1_TabPage1.Controls.Add(Me.label1)
            Me._SSTab1_TabPage1.Location = New System.Drawing.Point(4, 22)
            Me._SSTab1_TabPage1.Name = "_SSTab1_TabPage1"
            Me._SSTab1_TabPage1.Size = New System.Drawing.Size(385, 255)
            Me._SSTab1_TabPage1.TabIndex = 1
            Me._SSTab1_TabPage1.Text = "Database"
            '
            'chkBlankPassword
            '
            Me.chkBlankPassword.BackColor = System.Drawing.SystemColors.Control
            Me.chkBlankPassword.Cursor = System.Windows.Forms.Cursors.Default
            Me.chkBlankPassword.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.chkBlankPassword.ForeColor = System.Drawing.SystemColors.ControlText
            Me.chkBlankPassword.Location = New System.Drawing.Point(32, 232)
            Me.chkBlankPassword.Name = "chkBlankPassword"
            Me.chkBlankPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.chkBlankPassword.Size = New System.Drawing.Size(129, 17)
            Me.chkBlankPassword.TabIndex = 27
            Me.chkBlankPassword.Text = "Blank Password"
            Me.chkBlankPassword.UseVisualStyleBackColor = False
            '
            'Command1
            '
            Me.Command1.BackColor = System.Drawing.SystemColors.Control
            Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command1.Location = New System.Drawing.Point(216, 208)
            Me.Command1.Name = "Command1"
            Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command1.Size = New System.Drawing.Size(121, 25)
            Me.Command1.TabIndex = 18
            Me.Command1.Text = "Test Connection"
            Me.Command1.UseVisualStyleBackColor = False
            '
            'txtPassword
            '
            Me.txtPassword.AcceptsReturn = True
            Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
            Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtPassword.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
            Me.txtPassword.Location = New System.Drawing.Point(32, 208)
            Me.txtPassword.MaxLength = 0
            Me.txtPassword.Name = "txtPassword"
            Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
            Me.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtPassword.Size = New System.Drawing.Size(129, 19)
            Me.txtPassword.TabIndex = 16
            '
            'txtUserID
            '
            Me.txtUserID.AcceptsReturn = True
            Me.txtUserID.BackColor = System.Drawing.SystemColors.Window
            Me.txtUserID.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtUserID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtUserID.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtUserID.Location = New System.Drawing.Point(32, 168)
            Me.txtUserID.MaxLength = 0
            Me.txtUserID.Name = "txtUserID"
            Me.txtUserID.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtUserID.Size = New System.Drawing.Size(129, 19)
            Me.txtUserID.TabIndex = 14
            '
            'txtDataSource
            '
            Me.txtDataSource.AcceptsReturn = True
            Me.txtDataSource.BackColor = System.Drawing.SystemColors.Window
            Me.txtDataSource.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtDataSource.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtDataSource.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtDataSource.Location = New System.Drawing.Point(32, 104)
            Me.txtDataSource.MaxLength = 0
            Me.txtDataSource.Name = "txtDataSource"
            Me.txtDataSource.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtDataSource.Size = New System.Drawing.Size(249, 19)
            Me.txtDataSource.TabIndex = 12
            '
            'txtDatabase
            '
            Me.txtDatabase.AcceptsReturn = True
            Me.txtDatabase.BackColor = System.Drawing.SystemColors.Window
            Me.txtDatabase.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtDatabase.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtDatabase.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtDatabase.Location = New System.Drawing.Point(32, 64)
            Me.txtDatabase.MaxLength = 0
            Me.txtDatabase.Name = "txtDatabase"
            Me.txtDatabase.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtDatabase.Size = New System.Drawing.Size(249, 19)
            Me.txtDatabase.TabIndex = 10
            '
            'Label4
            '
            Me.Label4.BackColor = System.Drawing.SystemColors.Control
            Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label4.Location = New System.Drawing.Point(32, 192)
            Me.Label4.Name = "Label4"
            Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label4.Size = New System.Drawing.Size(97, 17)
            Me.Label4.TabIndex = 17
            Me.Label4.Text = "Database Password"
            '
            'Label3
            '
            Me.Label3.BackColor = System.Drawing.SystemColors.Control
            Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label3.Location = New System.Drawing.Point(32, 152)
            Me.Label3.Name = "Label3"
            Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label3.Size = New System.Drawing.Size(97, 17)
            Me.Label3.TabIndex = 15
            Me.Label3.Text = "Database User ID"
            '
            'Label2
            '
            Me.Label2.BackColor = System.Drawing.SystemColors.Control
            Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label2.Location = New System.Drawing.Point(32, 88)
            Me.Label2.Name = "Label2"
            Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label2.Size = New System.Drawing.Size(97, 17)
            Me.Label2.TabIndex = 13
            Me.Label2.Text = "Data Source"
            '
            'label1
            '
            Me.label1.BackColor = System.Drawing.SystemColors.Control
            Me.label1.Cursor = System.Windows.Forms.Cursors.Default
            Me.label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.label1.Location = New System.Drawing.Point(32, 48)
            Me.label1.Name = "label1"
            Me.label1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.label1.Size = New System.Drawing.Size(97, 17)
            Me.label1.TabIndex = 11
            Me.label1.Text = "Database Name"
            '
            'frmOptions
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.SystemColors.Control
            Me.CancelButton = Me.cmdCancel
            Me.ClientSize = New System.Drawing.Size(410, 347)
            Me.Controls.Add(Me._picOptions_3)
            Me.Controls.Add(Me._picOptions_2)
            Me.Controls.Add(Me._picOptions_1)
            Me.Controls.Add(Me.cmdApply)
            Me.Controls.Add(Me.cmdCancel)
            Me.Controls.Add(Me.cmdOK)
            Me.Controls.Add(Me.SSTab1)
            Me.Cursor = System.Windows.Forms.Cursors.Default
            Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.KeyPreview = True
            Me.Location = New System.Drawing.Point(171, 100)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "frmOptions"
            Me.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.ShowInTaskbar = False
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Options"
            Me._picOptions_3.ResumeLayout(False)
            Me._picOptions_2.ResumeLayout(False)
            Me._picOptions_1.ResumeLayout(False)
            Me.SSTab1.ResumeLayout(False)
            Me._SSTab1_TabPage0.ResumeLayout(False)
            Me.Frame1.ResumeLayout(False)
            Me._SSTab1_TabPage1.ResumeLayout(False)
            CType(Me.picOptions, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)

        End Sub
#End Region
    End Class
End Namespace