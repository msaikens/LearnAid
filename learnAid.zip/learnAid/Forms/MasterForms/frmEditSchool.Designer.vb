Namespace Forms.MasterForms
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmEditSchool
#Region "Windows Form Designer generated code "
        <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
            MyBase.New()
            'This call is required by the Windows Form Designer.
            InitializeComponent()
        End Sub
        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not components Is Nothing Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub
        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer
        Public ToolTip1 As System.Windows.Forms.ToolTip
        Public WithEvents txtCompany As System.Windows.Forms.TextBox
        Public WithEvents txtCost As System.Windows.Forms.TextBox
        Public WithEvents txtPrice As System.Windows.Forms.TextBox
        Public WithEvents txtCode As System.Windows.Forms.TextBox
        Public WithEvents txtSCHName As System.Windows.Forms.TextBox
        Public WithEvents txtHigh As System.Windows.Forms.TextBox
        Public WithEvents txtLow As System.Windows.Forms.TextBox
        Public WithEvents txtSexes As System.Windows.Forms.TextBox
        Public WithEvents txtType As System.Windows.Forms.TextBox
        Public WithEvents Label22 As System.Windows.Forms.Label
        Public WithEvents Label15 As System.Windows.Forms.Label
        Public WithEvents Label21 As System.Windows.Forms.Label
        Public WithEvents Image2 As System.Windows.Forms.PictureBox
        Public WithEvents Label20 As System.Windows.Forms.Label
        Public WithEvents Label1 As System.Windows.Forms.Label
        Public WithEvents Label14 As System.Windows.Forms.Label
        Public WithEvents Label13 As System.Windows.Forms.Label
        Public WithEvents Label12 As System.Windows.Forms.Label
        Public WithEvents Label2 As System.Windows.Forms.Label
        Public WithEvents _Frames_0 As System.Windows.Forms.GroupBox
        Public WithEvents ImageList1 As System.Windows.Forms.ImageList
        Public WithEvents Info As System.Windows.Forms.ToolStripButton
        Public WithEvents _Toolbar1_Button2 As System.Windows.Forms.ToolStripSeparator
        Public WithEvents Address As System.Windows.Forms.ToolStripButton
        Public WithEvents _Toolbar1_Button4 As System.Windows.Forms.ToolStripSeparator
        Public WithEvents Contact As System.Windows.Forms.ToolStripButton
        Public WithEvents _Toolbar1_Button6 As System.Windows.Forms.ToolStripSeparator
        Public WithEvents Consultant As System.Windows.Forms.ToolStripButton
        Public WithEvents Toolbar1 As System.Windows.Forms.ToolStrip
        Public WithEvents Command2 As System.Windows.Forms.Button
        Public WithEvents Command1 As System.Windows.Forms.Button
        Public WithEvents cboConsultant As System.Windows.Forms.ComboBox
        Public WithEvents Image4 As System.Windows.Forms.PictureBox
        Public WithEvents Label18 As System.Windows.Forms.Label
        Public WithEvents _Frames_3 As System.Windows.Forms.GroupBox
        Public WithEvents txtLocation As System.Windows.Forms.TextBox
        Public WithEvents txtAddress1 As System.Windows.Forms.TextBox
        Public WithEvents txtAddress2 As System.Windows.Forms.TextBox
        Public WithEvents txtCity As System.Windows.Forms.TextBox
        Public WithEvents txtZip As System.Windows.Forms.TextBox
        Public WithEvents Image3 As System.Windows.Forms.PictureBox
        Public WithEvents Label5 As System.Windows.Forms.Label
        Public WithEvents Label6 As System.Windows.Forms.Label
        Public WithEvents Label7 As System.Windows.Forms.Label
        Public WithEvents Label8 As System.Windows.Forms.Label
        Public WithEvents Label4 As System.Windows.Forms.Label
        Public WithEvents _Frames_1 As System.Windows.Forms.GroupBox
        Public WithEvents cboParentRep As System.Windows.Forms.ComboBox
        Public WithEvents cboPrincRep As System.Windows.Forms.ComboBox
        Public WithEvents txtPrincipal As System.Windows.Forms.TextBox
        Public WithEvents txtCounselor As System.Windows.Forms.TextBox
        Public WithEvents txtDirector As System.Windows.Forms.TextBox
        Public WithEvents txtFax As System.Windows.Forms.TextBox
        Public WithEvents txtPhone As System.Windows.Forms.TextBox
        Public WithEvents Image1 As System.Windows.Forms.PictureBox
        Public WithEvents Label19 As System.Windows.Forms.Label
        Public WithEvents Label17 As System.Windows.Forms.Label
        Public WithEvents Label16 As System.Windows.Forms.Label
        Public WithEvents Label11 As System.Windows.Forms.Label
        Public WithEvents Label10 As System.Windows.Forms.Label
        Public WithEvents Label9 As System.Windows.Forms.Label
        Public WithEvents Label3 As System.Windows.Forms.Label
        Public WithEvents _Frames_2 As System.Windows.Forms.GroupBox
        Public WithEvents Frames As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEditSchool))
            Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
            Me._Frames_0 = New System.Windows.Forms.GroupBox()
            Me.txtCompany = New System.Windows.Forms.TextBox()
            Me.txtCost = New System.Windows.Forms.TextBox()
            Me.txtPrice = New System.Windows.Forms.TextBox()
            Me.txtCode = New System.Windows.Forms.TextBox()
            Me.txtSCHName = New System.Windows.Forms.TextBox()
            Me.txtHigh = New System.Windows.Forms.TextBox()
            Me.txtLow = New System.Windows.Forms.TextBox()
            Me.txtSexes = New System.Windows.Forms.TextBox()
            Me.txtType = New System.Windows.Forms.TextBox()
            Me.Label22 = New System.Windows.Forms.Label()
            Me.Label15 = New System.Windows.Forms.Label()
            Me.Label21 = New System.Windows.Forms.Label()
            Me.Image2 = New System.Windows.Forms.PictureBox()
            Me.Label20 = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.Label14 = New System.Windows.Forms.Label()
            Me.Label13 = New System.Windows.Forms.Label()
            Me.Label12 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me._Frames_1 = New System.Windows.Forms.GroupBox()
            Me.txtLocation = New System.Windows.Forms.TextBox()
            Me.txtAddress1 = New System.Windows.Forms.TextBox()
            Me.txtAddress2 = New System.Windows.Forms.TextBox()
            Me.txtCity = New System.Windows.Forms.TextBox()
            Me.txtZip = New System.Windows.Forms.TextBox()
            Me.Image3 = New System.Windows.Forms.PictureBox()
            Me.Label5 = New System.Windows.Forms.Label()
            Me.Label6 = New System.Windows.Forms.Label()
            Me.Label7 = New System.Windows.Forms.Label()
            Me.Label8 = New System.Windows.Forms.Label()
            Me.Label4 = New System.Windows.Forms.Label()
            Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
            Me.Toolbar1 = New System.Windows.Forms.ToolStrip()
            Me.Info = New System.Windows.Forms.ToolStripButton()
            Me._Toolbar1_Button2 = New System.Windows.Forms.ToolStripSeparator()
            Me.Address = New System.Windows.Forms.ToolStripButton()
            Me._Toolbar1_Button4 = New System.Windows.Forms.ToolStripSeparator()
            Me.Contact = New System.Windows.Forms.ToolStripButton()
            Me._Toolbar1_Button6 = New System.Windows.Forms.ToolStripSeparator()
            Me.Consultant = New System.Windows.Forms.ToolStripButton()
            Me.Command2 = New System.Windows.Forms.Button()
            Me.Command1 = New System.Windows.Forms.Button()
            Me._Frames_3 = New System.Windows.Forms.GroupBox()
            Me.cboConsultant = New System.Windows.Forms.ComboBox()
            Me.Image4 = New System.Windows.Forms.PictureBox()
            Me.Label18 = New System.Windows.Forms.Label()
            Me._Frames_2 = New System.Windows.Forms.GroupBox()
            Me.cboParentRep = New System.Windows.Forms.ComboBox()
            Me.cboPrincRep = New System.Windows.Forms.ComboBox()
            Me.txtPrincipal = New System.Windows.Forms.TextBox()
            Me.txtCounselor = New System.Windows.Forms.TextBox()
            Me.txtDirector = New System.Windows.Forms.TextBox()
            Me.txtFax = New System.Windows.Forms.TextBox()
            Me.txtPhone = New System.Windows.Forms.TextBox()
            Me.Image1 = New System.Windows.Forms.PictureBox()
            Me.Label19 = New System.Windows.Forms.Label()
            Me.Label17 = New System.Windows.Forms.Label()
            Me.Label16 = New System.Windows.Forms.Label()
            Me.Label11 = New System.Windows.Forms.Label()
            Me.Label10 = New System.Windows.Forms.Label()
            Me.Label9 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.Frames = New Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(Me.components)
            Me._Frames_0.SuspendLayout()
            CType(Me.Image2, System.ComponentModel.ISupportInitialize).BeginInit()
            Me._Frames_1.SuspendLayout()
            CType(Me.Image3, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.Toolbar1.SuspendLayout()
            Me._Frames_3.SuspendLayout()
            CType(Me.Image4, System.ComponentModel.ISupportInitialize).BeginInit()
            Me._Frames_2.SuspendLayout()
            CType(Me.Image1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.Frames, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            '_Frames_0
            '
            Me._Frames_0.BackColor = System.Drawing.SystemColors.Control
            Me._Frames_0.Controls.Add(Me.txtCompany)
            Me._Frames_0.Controls.Add(Me.txtCost)
            Me._Frames_0.Controls.Add(Me.txtPrice)
            Me._Frames_0.Controls.Add(Me.txtCode)
            Me._Frames_0.Controls.Add(Me.txtSCHName)
            Me._Frames_0.Controls.Add(Me.txtHigh)
            Me._Frames_0.Controls.Add(Me.txtLow)
            Me._Frames_0.Controls.Add(Me.txtSexes)
            Me._Frames_0.Controls.Add(Me.txtType)
            Me._Frames_0.Controls.Add(Me.Label22)
            Me._Frames_0.Controls.Add(Me.Label15)
            Me._Frames_0.Controls.Add(Me.Label21)
            Me._Frames_0.Controls.Add(Me.Image2)
            Me._Frames_0.Controls.Add(Me.Label20)
            Me._Frames_0.Controls.Add(Me.Label1)
            Me._Frames_0.Controls.Add(Me.Label14)
            Me._Frames_0.Controls.Add(Me.Label13)
            Me._Frames_0.Controls.Add(Me.Label12)
            Me._Frames_0.Controls.Add(Me.Label2)
            Me._Frames_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Frames_0.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frames.SetIndex(Me._Frames_0, CType(0, Short))
            Me._Frames_0.Location = New System.Drawing.Point(9, 29)
            Me._Frames_0.Name = "_Frames_0"
            Me._Frames_0.Padding = New System.Windows.Forms.Padding(0)
            Me._Frames_0.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Frames_0.Size = New System.Drawing.Size(414, 253)
            Me._Frames_0.TabIndex = 32
            Me._Frames_0.TabStop = False
            '
            'txtCompany
            '
            Me.txtCompany.AcceptsReturn = True
            Me.txtCompany.BackColor = System.Drawing.SystemColors.Window
            Me.txtCompany.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtCompany.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCompany.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtCompany.Location = New System.Drawing.Point(80, 192)
            Me.txtCompany.MaxLength = 0
            Me.txtCompany.Name = "txtCompany"
            Me.txtCompany.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtCompany.Size = New System.Drawing.Size(129, 20)
            Me.txtCompany.TabIndex = 20
            '
            'txtCost
            '
            Me.txtCost.AcceptsReturn = True
            Me.txtCost.BackColor = System.Drawing.SystemColors.Window
            Me.txtCost.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtCost.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCost.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtCost.Location = New System.Drawing.Point(286, 153)
            Me.txtCost.MaxLength = 0
            Me.txtCost.Name = "txtCost"
            Me.txtCost.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtCost.Size = New System.Drawing.Size(57, 20)
            Me.txtCost.TabIndex = 48
            '
            'txtPrice
            '
            Me.txtPrice.AcceptsReturn = True
            Me.txtPrice.BackColor = System.Drawing.SystemColors.Window
            Me.txtPrice.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtPrice.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtPrice.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtPrice.Location = New System.Drawing.Point(80, 152)
            Me.txtPrice.MaxLength = 0
            Me.txtPrice.Name = "txtPrice"
            Me.txtPrice.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtPrice.Size = New System.Drawing.Size(129, 20)
            Me.txtPrice.TabIndex = 19
            '
            'txtCode
            '
            Me.txtCode.AcceptsReturn = True
            Me.txtCode.BackColor = System.Drawing.SystemColors.Window
            Me.txtCode.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtCode.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCode.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtCode.Location = New System.Drawing.Point(288, 32)
            Me.txtCode.MaxLength = 10
            Me.txtCode.Name = "txtCode"
            Me.txtCode.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtCode.Size = New System.Drawing.Size(65, 20)
            Me.txtCode.TabIndex = 14
            '
            'txtSCHName
            '
            Me.txtSCHName.AcceptsReturn = True
            Me.txtSCHName.BackColor = System.Drawing.SystemColors.Window
            Me.txtSCHName.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtSCHName.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtSCHName.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtSCHName.Location = New System.Drawing.Point(80, 32)
            Me.txtSCHName.MaxLength = 60
            Me.txtSCHName.Name = "txtSCHName"
            Me.txtSCHName.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtSCHName.Size = New System.Drawing.Size(185, 20)
            Me.txtSCHName.TabIndex = 13
            '
            'txtHigh
            '
            Me.txtHigh.AcceptsReturn = True
            Me.txtHigh.BackColor = System.Drawing.SystemColors.Window
            Me.txtHigh.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtHigh.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtHigh.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtHigh.Location = New System.Drawing.Point(286, 114)
            Me.txtHigh.MaxLength = 0
            Me.txtHigh.Name = "txtHigh"
            Me.txtHigh.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtHigh.Size = New System.Drawing.Size(57, 20)
            Me.txtHigh.TabIndex = 18
            Me.txtHigh.Tag = resources.GetString("txtHigh.Tag")
            '
            'txtLow
            '
            Me.txtLow.AcceptsReturn = True
            Me.txtLow.BackColor = System.Drawing.SystemColors.Window
            Me.txtLow.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtLow.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtLow.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtLow.Location = New System.Drawing.Point(80, 112)
            Me.txtLow.MaxLength = 0
            Me.txtLow.Name = "txtLow"
            Me.txtLow.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtLow.Size = New System.Drawing.Size(49, 20)
            Me.txtLow.TabIndex = 17
            Me.txtLow.Tag = "Validate Text -Required -AllowDigits -FieldMustBe >= 0 <= 12 -InvalidValueMsg The" & _
        " Low Grade is invalid. -OutOfRangeMsg The Low Grade must be between 0 and 12. -R" & _
        "equiredMSG The Low grade is required."
            '
            'txtSexes
            '
            Me.txtSexes.AcceptsReturn = True
            Me.txtSexes.BackColor = System.Drawing.SystemColors.Window
            Me.txtSexes.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtSexes.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtSexes.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtSexes.Location = New System.Drawing.Point(286, 72)
            Me.txtSexes.MaxLength = 1
            Me.txtSexes.Name = "txtSexes"
            Me.txtSexes.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtSexes.Size = New System.Drawing.Size(65, 20)
            Me.txtSexes.TabIndex = 16
            Me.txtSexes.Tag = "Validate Text -AllowOthers mMfFcC -MaxLength 1 -InvalidValueMsg The Sexes Field m" & _
        "ust be M,F or C. -LengthMsg The Sexes Field must be only one character lenght."
            '
            'txtType
            '
            Me.txtType.AcceptsReturn = True
            Me.txtType.BackColor = System.Drawing.SystemColors.Window
            Me.txtType.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtType.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtType.Location = New System.Drawing.Point(80, 72)
            Me.txtType.MaxLength = 15
            Me.txtType.Name = "txtType"
            Me.txtType.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtType.Size = New System.Drawing.Size(129, 20)
            Me.txtType.TabIndex = 15
            '
            'Label22
            '
            Me.Label22.BackColor = System.Drawing.SystemColors.Control
            Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label22.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label22.Location = New System.Drawing.Point(80, 176)
            Me.Label22.Name = "Label22"
            Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label22.Size = New System.Drawing.Size(81, 17)
            Me.Label22.TabIndex = 50
            Me.Label22.Text = "Company:"
            '
            'Label15
            '
            Me.Label15.BackColor = System.Drawing.SystemColors.Control
            Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label15.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label15.Location = New System.Drawing.Point(286, 138)
            Me.Label15.Name = "Label15"
            Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label15.Size = New System.Drawing.Size(73, 17)
            Me.Label15.TabIndex = 49
            Me.Label15.Text = "Milleage Cost:"
            '
            'Label21
            '
            Me.Label21.BackColor = System.Drawing.SystemColors.Control
            Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label21.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label21.Location = New System.Drawing.Point(80, 136)
            Me.Label21.Name = "Label21"
            Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label21.Size = New System.Drawing.Size(113, 17)
            Me.Label21.TabIndex = 47
            Me.Label21.Text = "Price per Student"
            '
            'Image2
            '
            Me.Image2.Cursor = System.Windows.Forms.Cursors.Default
            Me.Image2.Image = CType(resources.GetObject("Image2.Image"), System.Drawing.Image)
            Me.Image2.Location = New System.Drawing.Point(32, 24)
            Me.Image2.Name = "Image2"
            Me.Image2.Size = New System.Drawing.Size(32, 32)
            Me.Image2.TabIndex = 51
            Me.Image2.TabStop = False
            '
            'Label20
            '
            Me.Label20.BackColor = System.Drawing.SystemColors.Control
            Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label20.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label20.Location = New System.Drawing.Point(272, 16)
            Me.Label20.Name = "Label20"
            Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label20.Size = New System.Drawing.Size(81, 17)
            Me.Label20.TabIndex = 46
            Me.Label20.Text = "School Code:"
            Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'Label1
            '
            Me.Label1.BackColor = System.Drawing.SystemColors.Control
            Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label1.Location = New System.Drawing.Point(80, 16)
            Me.Label1.Name = "Label1"
            Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label1.Size = New System.Drawing.Size(81, 17)
            Me.Label1.TabIndex = 44
            Me.Label1.Text = "School Name:"
            Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'Label14
            '
            Me.Label14.BackColor = System.Drawing.SystemColors.Control
            Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label14.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label14.Location = New System.Drawing.Point(286, 99)
            Me.Label14.Name = "Label14"
            Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label14.Size = New System.Drawing.Size(57, 17)
            Me.Label14.TabIndex = 36
            Me.Label14.Text = "High Grade:"
            '
            'Label13
            '
            Me.Label13.BackColor = System.Drawing.SystemColors.Control
            Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label13.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label13.Location = New System.Drawing.Point(80, 96)
            Me.Label13.Name = "Label13"
            Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label13.Size = New System.Drawing.Size(81, 17)
            Me.Label13.TabIndex = 35
            Me.Label13.Text = "Low Grade:"
            '
            'Label12
            '
            Me.Label12.BackColor = System.Drawing.SystemColors.Control
            Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label12.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label12.Location = New System.Drawing.Point(288, 56)
            Me.Label12.Name = "Label12"
            Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label12.Size = New System.Drawing.Size(33, 17)
            Me.Label12.TabIndex = 34
            Me.Label12.Text = "Sex:"
            '
            'Label2
            '
            Me.Label2.BackColor = System.Drawing.SystemColors.Control
            Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label2.Location = New System.Drawing.Point(80, 56)
            Me.Label2.Name = "Label2"
            Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label2.Size = New System.Drawing.Size(81, 17)
            Me.Label2.TabIndex = 33
            Me.Label2.Text = "School Type:"
            '
            '_Frames_1
            '
            Me._Frames_1.BackColor = System.Drawing.SystemColors.Control
            Me._Frames_1.Controls.Add(Me.txtLocation)
            Me._Frames_1.Controls.Add(Me.txtAddress1)
            Me._Frames_1.Controls.Add(Me.txtAddress2)
            Me._Frames_1.Controls.Add(Me.txtCity)
            Me._Frames_1.Controls.Add(Me.txtZip)
            Me._Frames_1.Controls.Add(Me.Image3)
            Me._Frames_1.Controls.Add(Me.Label5)
            Me._Frames_1.Controls.Add(Me.Label6)
            Me._Frames_1.Controls.Add(Me.Label7)
            Me._Frames_1.Controls.Add(Me.Label8)
            Me._Frames_1.Controls.Add(Me.Label4)
            Me._Frames_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Frames_1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frames.SetIndex(Me._Frames_1, CType(1, Short))
            Me._Frames_1.Location = New System.Drawing.Point(436, 30)
            Me._Frames_1.Name = "_Frames_1"
            Me._Frames_1.Padding = New System.Windows.Forms.Padding(0)
            Me._Frames_1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Frames_1.Size = New System.Drawing.Size(414, 252)
            Me._Frames_1.TabIndex = 21
            Me._Frames_1.TabStop = False
            '
            'txtLocation
            '
            Me.txtLocation.AcceptsReturn = True
            Me.txtLocation.BackColor = System.Drawing.SystemColors.Window
            Me.txtLocation.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtLocation.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtLocation.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtLocation.Location = New System.Drawing.Point(128, 152)
            Me.txtLocation.MaxLength = 50
            Me.txtLocation.Name = "txtLocation"
            Me.txtLocation.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtLocation.Size = New System.Drawing.Size(169, 20)
            Me.txtLocation.TabIndex = 4
            '
            'txtAddress1
            '
            Me.txtAddress1.AcceptsReturn = True
            Me.txtAddress1.BackColor = System.Drawing.SystemColors.Window
            Me.txtAddress1.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtAddress1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtAddress1.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtAddress1.Location = New System.Drawing.Point(128, 32)
            Me.txtAddress1.MaxLength = 258
            Me.txtAddress1.Name = "txtAddress1"
            Me.txtAddress1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtAddress1.Size = New System.Drawing.Size(169, 20)
            Me.txtAddress1.TabIndex = 0
            '
            'txtAddress2
            '
            Me.txtAddress2.AcceptsReturn = True
            Me.txtAddress2.BackColor = System.Drawing.SystemColors.Window
            Me.txtAddress2.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtAddress2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtAddress2.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtAddress2.Location = New System.Drawing.Point(128, 72)
            Me.txtAddress2.MaxLength = 25
            Me.txtAddress2.Name = "txtAddress2"
            Me.txtAddress2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtAddress2.Size = New System.Drawing.Size(169, 20)
            Me.txtAddress2.TabIndex = 1
            '
            'txtCity
            '
            Me.txtCity.AcceptsReturn = True
            Me.txtCity.BackColor = System.Drawing.SystemColors.Window
            Me.txtCity.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCity.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtCity.Location = New System.Drawing.Point(128, 112)
            Me.txtCity.MaxLength = 30
            Me.txtCity.Name = "txtCity"
            Me.txtCity.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtCity.Size = New System.Drawing.Size(105, 20)
            Me.txtCity.TabIndex = 2
            '
            'txtZip
            '
            Me.txtZip.AcceptsReturn = True
            Me.txtZip.BackColor = System.Drawing.SystemColors.Window
            Me.txtZip.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtZip.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtZip.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtZip.Location = New System.Drawing.Point(232, 112)
            Me.txtZip.MaxLength = 10
            Me.txtZip.Name = "txtZip"
            Me.txtZip.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtZip.Size = New System.Drawing.Size(65, 20)
            Me.txtZip.TabIndex = 3
            Me.txtZip.Tag = "Validate ZipCode -InvalidValueMsg The Zip Code is invalid."
            '
            'Image3
            '
            Me.Image3.Cursor = System.Windows.Forms.Cursors.Default
            Me.Image3.Image = CType(resources.GetObject("Image3.Image"), System.Drawing.Image)
            Me.Image3.Location = New System.Drawing.Point(24, 24)
            Me.Image3.Name = "Image3"
            Me.Image3.Size = New System.Drawing.Size(32, 32)
            Me.Image3.TabIndex = 5
            Me.Image3.TabStop = False
            '
            'Label5
            '
            Me.Label5.BackColor = System.Drawing.SystemColors.Control
            Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label5.Location = New System.Drawing.Point(128, 56)
            Me.Label5.Name = "Label5"
            Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label5.Size = New System.Drawing.Size(73, 17)
            Me.Label5.TabIndex = 25
            Me.Label5.Text = "Address 2:"
            '
            'Label6
            '
            Me.Label6.BackColor = System.Drawing.SystemColors.Control
            Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label6.Location = New System.Drawing.Point(128, 96)
            Me.Label6.Name = "Label6"
            Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label6.Size = New System.Drawing.Size(73, 17)
            Me.Label6.TabIndex = 24
            Me.Label6.Text = "City:"
            '
            'Label7
            '
            Me.Label7.BackColor = System.Drawing.SystemColors.Control
            Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label7.Location = New System.Drawing.Point(232, 96)
            Me.Label7.Name = "Label7"
            Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label7.Size = New System.Drawing.Size(73, 17)
            Me.Label7.TabIndex = 23
            Me.Label7.Text = "Zip Code:"
            '
            'Label8
            '
            Me.Label8.BackColor = System.Drawing.SystemColors.Control
            Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label8.Location = New System.Drawing.Point(128, 136)
            Me.Label8.Name = "Label8"
            Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label8.Size = New System.Drawing.Size(73, 17)
            Me.Label8.TabIndex = 22
            Me.Label8.Text = "Location:"
            '
            'Label4
            '
            Me.Label4.BackColor = System.Drawing.SystemColors.Control
            Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label4.Location = New System.Drawing.Point(128, 16)
            Me.Label4.Name = "Label4"
            Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label4.Size = New System.Drawing.Size(73, 17)
            Me.Label4.TabIndex = 26
            Me.Label4.Text = "Address 1:"
            '
            'ImageList1
            '
            Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
            Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
            Me.ImageList1.TransparentColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
            '
            'Toolbar1
            '
            Me.Toolbar1.ImageList = Me.ImageList1
            Me.Toolbar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Info, Me._Toolbar1_Button2, Me.Address, Me._Toolbar1_Button4, Me.Contact, Me._Toolbar1_Button6, Me.Consultant})
            Me.Toolbar1.Location = New System.Drawing.Point(0, 0)
            Me.Toolbar1.Name = "Toolbar1"
            Me.Toolbar1.Size = New System.Drawing.Size(430, 25)
            Me.Toolbar1.TabIndex = 45
            '
            'Info
            '
            Me.Info.AutoSize = False
            Me.Info.Checked = True
            Me.Info.CheckOnClick = True
            Me.Info.CheckState = System.Windows.Forms.CheckState.Checked
            Me.Info.Image = Global.learnAid.My.Resources.Resources.school
            Me.Info.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.Info.Name = "Info"
            Me.Info.Size = New System.Drawing.Size(90, 22)
            Me.Info.Text = "School Info"
            '
            '_Toolbar1_Button2
            '
            Me._Toolbar1_Button2.AutoSize = False
            Me._Toolbar1_Button2.Name = "_Toolbar1_Button2"
            Me._Toolbar1_Button2.Size = New System.Drawing.Size(10, 22)
            '
            'Address
            '
            Me.Address.AutoSize = False
            Me.Address.CheckOnClick = True
            Me.Address.Image = Global.learnAid.My.Resources.Resources.RESENDL
            Me.Address.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.Address.Name = "Address"
            Me.Address.Size = New System.Drawing.Size(82, 22)
            Me.Address.Text = "Address"
            '
            '_Toolbar1_Button4
            '
            Me._Toolbar1_Button4.AutoSize = False
            Me._Toolbar1_Button4.Name = "_Toolbar1_Button4"
            Me._Toolbar1_Button4.Size = New System.Drawing.Size(10, 22)
            '
            'Contact
            '
            Me.Contact.AutoSize = False
            Me.Contact.CheckOnClick = True
            Me.Contact.Image = Global.learnAid.My.Resources.Resources.CONTACTL
            Me.Contact.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.Contact.Name = "Contact"
            Me.Contact.Size = New System.Drawing.Size(82, 22)
            Me.Contact.Text = "Contact"
            '
            '_Toolbar1_Button6
            '
            Me._Toolbar1_Button6.AutoSize = False
            Me._Toolbar1_Button6.Name = "_Toolbar1_Button6"
            Me._Toolbar1_Button6.Size = New System.Drawing.Size(10, 22)
            '
            'Consultant
            '
            Me.Consultant.AutoSize = False
            Me.Consultant.CheckOnClick = True
            Me.Consultant.Image = Global.learnAid.My.Resources.Resources.consultants
            Me.Consultant.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.Consultant.Name = "Consultant"
            Me.Consultant.Size = New System.Drawing.Size(82, 22)
            Me.Consultant.Text = "Consultant"
            '
            'Command2
            '
            Me.Command2.BackColor = System.Drawing.SystemColors.Control
            Me.Command2.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command2.Location = New System.Drawing.Point(336, 288)
            Me.Command2.Name = "Command2"
            Me.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command2.Size = New System.Drawing.Size(81, 25)
            Me.Command2.TabIndex = 42
            Me.Command2.Text = "&Cancel"
            Me.Command2.UseVisualStyleBackColor = False
            '
            'Command1
            '
            Me.Command1.BackColor = System.Drawing.SystemColors.Control
            Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
            Me.Command1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Command1.Location = New System.Drawing.Point(249, 288)
            Me.Command1.Name = "Command1"
            Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Command1.Size = New System.Drawing.Size(81, 25)
            Me.Command1.TabIndex = 41
            Me.Command1.Text = "&OK"
            Me.Command1.UseVisualStyleBackColor = False
            '
            '_Frames_3
            '
            Me._Frames_3.BackColor = System.Drawing.SystemColors.Control
            Me._Frames_3.Controls.Add(Me.cboConsultant)
            Me._Frames_3.Controls.Add(Me.Image4)
            Me._Frames_3.Controls.Add(Me.Label18)
            Me._Frames_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Frames_3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frames.SetIndex(Me._Frames_3, CType(3, Short))
            Me._Frames_3.Location = New System.Drawing.Point(401, 330)
            Me._Frames_3.Name = "_Frames_3"
            Me._Frames_3.Padding = New System.Windows.Forms.Padding(0)
            Me._Frames_3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Frames_3.Size = New System.Drawing.Size(414, 253)
            Me._Frames_3.TabIndex = 39
            Me._Frames_3.TabStop = False
            '
            'cboConsultant
            '
            Me.cboConsultant.BackColor = System.Drawing.SystemColors.Window
            Me.cboConsultant.Cursor = System.Windows.Forms.Cursors.Default
            Me.cboConsultant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.cboConsultant.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.cboConsultant.ForeColor = System.Drawing.SystemColors.WindowText
            Me.cboConsultant.Location = New System.Drawing.Point(96, 32)
            Me.cboConsultant.Name = "cboConsultant"
            Me.cboConsultant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.cboConsultant.Size = New System.Drawing.Size(121, 22)
            Me.cboConsultant.TabIndex = 5
            '
            'Image4
            '
            Me.Image4.Cursor = System.Windows.Forms.Cursors.Default
            Me.Image4.Image = CType(resources.GetObject("Image4.Image"), System.Drawing.Image)
            Me.Image4.Location = New System.Drawing.Point(24, 32)
            Me.Image4.Name = "Image4"
            Me.Image4.Size = New System.Drawing.Size(32, 32)
            Me.Image4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.Image4.TabIndex = 6
            Me.Image4.TabStop = False
            '
            'Label18
            '
            Me.Label18.BackColor = System.Drawing.SystemColors.Control
            Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label18.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label18.Location = New System.Drawing.Point(96, 16)
            Me.Label18.Name = "Label18"
            Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label18.Size = New System.Drawing.Size(73, 17)
            Me.Label18.TabIndex = 40
            Me.Label18.Text = "Consultant:"
            '
            '_Frames_2
            '
            Me._Frames_2.BackColor = System.Drawing.SystemColors.Control
            Me._Frames_2.Controls.Add(Me.cboParentRep)
            Me._Frames_2.Controls.Add(Me.cboPrincRep)
            Me._Frames_2.Controls.Add(Me.txtPrincipal)
            Me._Frames_2.Controls.Add(Me.txtCounselor)
            Me._Frames_2.Controls.Add(Me.txtDirector)
            Me._Frames_2.Controls.Add(Me.txtFax)
            Me._Frames_2.Controls.Add(Me.txtPhone)
            Me._Frames_2.Controls.Add(Me.Image1)
            Me._Frames_2.Controls.Add(Me.Label19)
            Me._Frames_2.Controls.Add(Me.Label17)
            Me._Frames_2.Controls.Add(Me.Label16)
            Me._Frames_2.Controls.Add(Me.Label11)
            Me._Frames_2.Controls.Add(Me.Label10)
            Me._Frames_2.Controls.Add(Me.Label9)
            Me._Frames_2.Controls.Add(Me.Label3)
            Me._Frames_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Frames_2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frames.SetIndex(Me._Frames_2, CType(2, Short))
            Me._Frames_2.Location = New System.Drawing.Point(0, 330)
            Me._Frames_2.Name = "_Frames_2"
            Me._Frames_2.Padding = New System.Windows.Forms.Padding(0)
            Me._Frames_2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Frames_2.Size = New System.Drawing.Size(395, 248)
            Me._Frames_2.TabIndex = 27
            Me._Frames_2.TabStop = False
            '
            'cboParentRep
            '
            Me.cboParentRep.BackColor = System.Drawing.SystemColors.Window
            Me.cboParentRep.Cursor = System.Windows.Forms.Cursors.Default
            Me.cboParentRep.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.cboParentRep.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.cboParentRep.ForeColor = System.Drawing.SystemColors.WindowText
            Me.cboParentRep.Location = New System.Drawing.Point(224, 80)
            Me.cboParentRep.Name = "cboParentRep"
            Me.cboParentRep.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.cboParentRep.Size = New System.Drawing.Size(121, 22)
            Me.cboParentRep.TabIndex = 12
            Me.cboParentRep.Tag = "Validate Text -Required -RequiredMsg Potential Formula is a required field!"
            '
            'cboPrincRep
            '
            Me.cboPrincRep.BackColor = System.Drawing.SystemColors.Window
            Me.cboPrincRep.Cursor = System.Windows.Forms.Cursors.Default
            Me.cboPrincRep.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.cboPrincRep.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.cboPrincRep.ForeColor = System.Drawing.SystemColors.WindowText
            Me.cboPrincRep.Location = New System.Drawing.Point(224, 32)
            Me.cboPrincRep.Name = "cboPrincRep"
            Me.cboPrincRep.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.cboPrincRep.Size = New System.Drawing.Size(121, 22)
            Me.cboPrincRep.TabIndex = 11
            Me.cboPrincRep.Tag = "Validate Text -Required -RequiredMsg Principal Report Version is a required field" & _
        "!"
            '
            'txtPrincipal
            '
            Me.txtPrincipal.AcceptsReturn = True
            Me.txtPrincipal.BackColor = System.Drawing.SystemColors.Window
            Me.txtPrincipal.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtPrincipal.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtPrincipal.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtPrincipal.Location = New System.Drawing.Point(96, 32)
            Me.txtPrincipal.MaxLength = 25
            Me.txtPrincipal.Name = "txtPrincipal"
            Me.txtPrincipal.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtPrincipal.Size = New System.Drawing.Size(121, 20)
            Me.txtPrincipal.TabIndex = 6
            '
            'txtCounselor
            '
            Me.txtCounselor.AcceptsReturn = True
            Me.txtCounselor.BackColor = System.Drawing.SystemColors.Window
            Me.txtCounselor.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtCounselor.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCounselor.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtCounselor.Location = New System.Drawing.Point(96, 128)
            Me.txtCounselor.MaxLength = 25
            Me.txtCounselor.Name = "txtCounselor"
            Me.txtCounselor.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtCounselor.Size = New System.Drawing.Size(121, 20)
            Me.txtCounselor.TabIndex = 8
            '
            'txtDirector
            '
            Me.txtDirector.AcceptsReturn = True
            Me.txtDirector.BackColor = System.Drawing.SystemColors.Window
            Me.txtDirector.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtDirector.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtDirector.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtDirector.Location = New System.Drawing.Point(96, 80)
            Me.txtDirector.MaxLength = 25
            Me.txtDirector.Name = "txtDirector"
            Me.txtDirector.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtDirector.Size = New System.Drawing.Size(121, 20)
            Me.txtDirector.TabIndex = 7
            '
            'txtFax
            '
            Me.txtFax.AcceptsReturn = True
            Me.txtFax.BackColor = System.Drawing.SystemColors.Window
            Me.txtFax.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtFax.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtFax.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtFax.Location = New System.Drawing.Point(96, 216)
            Me.txtFax.MaxLength = 14
            Me.txtFax.Name = "txtFax"
            Me.txtFax.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtFax.Size = New System.Drawing.Size(121, 20)
            Me.txtFax.TabIndex = 10
            Me.txtFax.Tag = "Validate Phone -InvalidValueMsg The Fax is invalid."
            '
            'txtPhone
            '
            Me.txtPhone.AcceptsReturn = True
            Me.txtPhone.BackColor = System.Drawing.SystemColors.Window
            Me.txtPhone.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtPhone.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtPhone.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtPhone.Location = New System.Drawing.Point(96, 176)
            Me.txtPhone.MaxLength = 14
            Me.txtPhone.Name = "txtPhone"
            Me.txtPhone.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtPhone.Size = New System.Drawing.Size(121, 20)
            Me.txtPhone.TabIndex = 9
            Me.txtPhone.Tag = "Validate Phone -InvalidValueMsg The Phone is invalid."
            '
            'Image1
            '
            Me.Image1.Cursor = System.Windows.Forms.Cursors.Default
            Me.Image1.Image = CType(resources.GetObject("Image1.Image"), System.Drawing.Image)
            Me.Image1.Location = New System.Drawing.Point(32, 24)
            Me.Image1.Name = "Image1"
            Me.Image1.Size = New System.Drawing.Size(32, 32)
            Me.Image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.Image1.TabIndex = 13
            Me.Image1.TabStop = False
            '
            'Label19
            '
            Me.Label19.BackColor = System.Drawing.SystemColors.Control
            Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label19.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label19.Location = New System.Drawing.Point(96, 16)
            Me.Label19.Name = "Label19"
            Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label19.Size = New System.Drawing.Size(73, 17)
            Me.Label19.TabIndex = 43
            Me.Label19.Text = "Principal:"
            '
            'Label17
            '
            Me.Label17.BackColor = System.Drawing.SystemColors.Control
            Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label17.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label17.Location = New System.Drawing.Point(224, 64)
            Me.Label17.Name = "Label17"
            Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label17.Size = New System.Drawing.Size(121, 17)
            Me.Label17.TabIndex = 38
            Me.Label17.Text = "Potential Formula:"
            '
            'Label16
            '
            Me.Label16.BackColor = System.Drawing.SystemColors.Control
            Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label16.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label16.Location = New System.Drawing.Point(224, 16)
            Me.Label16.Name = "Label16"
            Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label16.Size = New System.Drawing.Size(121, 17)
            Me.Label16.TabIndex = 37
            Me.Label16.Text = "Report Version:"
            '
            'Label11
            '
            Me.Label11.BackColor = System.Drawing.SystemColors.Control
            Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label11.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label11.Location = New System.Drawing.Point(96, 112)
            Me.Label11.Name = "Label11"
            Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label11.Size = New System.Drawing.Size(73, 17)
            Me.Label11.TabIndex = 31
            Me.Label11.Text = "Counselor:"
            '
            'Label10
            '
            Me.Label10.BackColor = System.Drawing.SystemColors.Control
            Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label10.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label10.Location = New System.Drawing.Point(96, 64)
            Me.Label10.Name = "Label10"
            Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label10.Size = New System.Drawing.Size(73, 17)
            Me.Label10.TabIndex = 30
            Me.Label10.Text = "Director:"
            '
            'Label9
            '
            Me.Label9.BackColor = System.Drawing.SystemColors.Control
            Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label9.Location = New System.Drawing.Point(96, 200)
            Me.Label9.Name = "Label9"
            Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label9.Size = New System.Drawing.Size(73, 17)
            Me.Label9.TabIndex = 29
            Me.Label9.Text = "Fax:"
            '
            'Label3
            '
            Me.Label3.BackColor = System.Drawing.SystemColors.Control
            Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label3.Location = New System.Drawing.Point(96, 160)
            Me.Label3.Name = "Label3"
            Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.Label3.Size = New System.Drawing.Size(73, 17)
            Me.Label3.TabIndex = 28
            Me.Label3.Text = "Phone:"
            '
            'frmEditSchool
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.SystemColors.Control
            Me.ClientSize = New System.Drawing.Size(430, 318)
            Me.ControlBox = False
            Me.Controls.Add(Me._Frames_0)
            Me.Controls.Add(Me._Frames_3)
            Me.Controls.Add(Me.Toolbar1)
            Me.Controls.Add(Me._Frames_2)
            Me.Controls.Add(Me.Command1)
            Me.Controls.Add(Me.Command2)
            Me.Controls.Add(Me._Frames_1)
            Me.Cursor = System.Windows.Forms.Cursors.Default
            Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
            Me.Location = New System.Drawing.Point(3, 22)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "frmEditSchool"
            Me.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = " "
            Me._Frames_0.ResumeLayout(False)
            Me._Frames_0.PerformLayout()
            CType(Me.Image2, System.ComponentModel.ISupportInitialize).EndInit()
            Me._Frames_1.ResumeLayout(False)
            Me._Frames_1.PerformLayout()
            CType(Me.Image3, System.ComponentModel.ISupportInitialize).EndInit()
            Me.Toolbar1.ResumeLayout(False)
            Me.Toolbar1.PerformLayout()
            Me._Frames_3.ResumeLayout(False)
            CType(Me.Image4, System.ComponentModel.ISupportInitialize).EndInit()
            Me._Frames_2.ResumeLayout(False)
            Me._Frames_2.PerformLayout()
            CType(Me.Image1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.Frames, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
#End Region
    End Class
End Namespace