<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmOfficeTesting
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Text1 As System.Windows.Forms.TextBox
	Public WithEvents txtFile As System.Windows.Forms.TextBox
	Public WithEvents cboSemester As System.Windows.Forms.ComboBox
	Public WithEvents cboGrade As System.Windows.Forms.ComboBox
	Public WithEvents cboSchools As System.Windows.Forms.ComboBox
	Public WithEvents cboRen As System.Windows.Forms.ComboBox
	Public WithEvents cboLes As System.Windows.Forms.ComboBox
	Public WithEvents cboMat As System.Windows.Forms.ComboBox
	Public WithEvents cboNV As System.Windows.Forms.ComboBox
	Public WithEvents cmdOK As System.Windows.Forms.Button
	Public WithEvents cmdCancel As System.Windows.Forms.Button
	Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents _Toolbar1_Button1 As System.Windows.Forms.ToolStripButton
	Public WithEvents _Toolbar1_Button2 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents _Toolbar1_Button3 As System.Windows.Forms.ToolStripButton
	Public WithEvents _Toolbar1_Button4 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents _Toolbar1_Button5 As System.Windows.Forms.ToolStripButton
	Public WithEvents Toolbar1 As System.Windows.Forms.ToolStrip
	Public WithEvents _OfficeList_ColumnHeader_1 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_2 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_3 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_4 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_5 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_6 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_7 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_8 As System.Windows.Forms.ColumnHeader
	Public WithEvents _OfficeList_ColumnHeader_9 As System.Windows.Forms.ColumnHeader
	Public WithEvents OfficeList As System.Windows.Forms.ListView
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me.txtFile = New System.Windows.Forms.TextBox()
        Me.cboSemester = New System.Windows.Forms.ComboBox()
        Me.cboGrade = New System.Windows.Forms.ComboBox()
        Me.cboSchools = New System.Windows.Forms.ComboBox()
        Me.cboRen = New System.Windows.Forms.ComboBox()
        Me.cboLes = New System.Windows.Forms.ComboBox()
        Me.cboMat = New System.Windows.Forms.ComboBox()
        Me.cboNV = New System.Windows.Forms.ComboBox()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.Command1 = New System.Windows.Forms.Button()
        Me.Toolbar1 = New System.Windows.Forms.ToolStrip()
        Me._Toolbar1_Button1 = New System.Windows.Forms.ToolStripButton()
        Me._Toolbar1_Button2 = New System.Windows.Forms.ToolStripSeparator()
        Me._Toolbar1_Button3 = New System.Windows.Forms.ToolStripButton()
        Me._Toolbar1_Button4 = New System.Windows.Forms.ToolStripSeparator()
        Me._Toolbar1_Button5 = New System.Windows.Forms.ToolStripButton()
        Me.OfficeList = New System.Windows.Forms.ListView()
        Me._OfficeList_ColumnHeader_1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._OfficeList_ColumnHeader_9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Toolbar1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Text1
        '
        Me.Text1.AcceptsReturn = True
        Me.Text1.BackColor = System.Drawing.SystemColors.Window
        Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text1.Location = New System.Drawing.Point(8, 192)
        Me.Text1.MaxLength = 0
        Me.Text1.Name = "Text1"
        Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text1.Size = New System.Drawing.Size(241, 23)
        Me.Text1.TabIndex = 19
        Me.Text1.Text = "Text1"
        '
        'txtFile
        '
        Me.txtFile.AcceptsReturn = True
        Me.txtFile.BackColor = System.Drawing.SystemColors.Window
        Me.txtFile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFile.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFile.Location = New System.Drawing.Point(176, 81)
        Me.txtFile.MaxLength = 0
        Me.txtFile.Name = "txtFile"
        Me.txtFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFile.Size = New System.Drawing.Size(31, 23)
        Me.txtFile.TabIndex = 10
        Me.txtFile.Tag = "Validate Text -Required -RequiredMsg The File Code Field is a required."
        '
        'cboSemester
        '
        Me.cboSemester.BackColor = System.Drawing.SystemColors.Window
        Me.cboSemester.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSemester.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSemester.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSemester.Location = New System.Drawing.Point(338, 40)
        Me.cboSemester.Name = "cboSemester"
        Me.cboSemester.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSemester.Size = New System.Drawing.Size(124, 24)
        Me.cboSemester.TabIndex = 9
        Me.cboSemester.Tag = "Validate Text -Required -RequiredMsg Semester is a required field!"
        Me.cboSemester.Text = "cboSemester"
        '
        'cboGrade
        '
        Me.cboGrade.BackColor = System.Drawing.SystemColors.Window
        Me.cboGrade.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboGrade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGrade.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboGrade.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboGrade.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.cboGrade.Location = New System.Drawing.Point(8, 81)
        Me.cboGrade.Name = "cboGrade"
        Me.cboGrade.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboGrade.Size = New System.Drawing.Size(161, 24)
        Me.cboGrade.TabIndex = 8
        Me.cboGrade.Tag = "Validate Text -Required -RequiredMsg Grade is a required field!"
        '
        'cboSchools
        '
        Me.cboSchools.BackColor = System.Drawing.SystemColors.Window
        Me.cboSchools.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSchools.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSchools.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSchools.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSchools.Location = New System.Drawing.Point(8, 40)
        Me.cboSchools.Name = "cboSchools"
        Me.cboSchools.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSchools.Size = New System.Drawing.Size(324, 24)
        Me.cboSchools.TabIndex = 7
        Me.cboSchools.Tag = "Validate Text -Required -RequiredMsg School is a required field!"
        '
        'cboRen
        '
        Me.cboRen.BackColor = System.Drawing.SystemColors.Window
        Me.cboRen.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboRen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRen.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboRen.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboRen.Location = New System.Drawing.Point(245, 132)
        Me.cboRen.Name = "cboRen"
        Me.cboRen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboRen.Size = New System.Drawing.Size(73, 24)
        Me.cboRen.TabIndex = 6
        '
        'cboLes
        '
        Me.cboLes.BackColor = System.Drawing.SystemColors.Window
        Me.cboLes.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboLes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLes.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboLes.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboLes.Location = New System.Drawing.Point(166, 132)
        Me.cboLes.Name = "cboLes"
        Me.cboLes.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboLes.Size = New System.Drawing.Size(73, 24)
        Me.cboLes.TabIndex = 5
        '
        'cboMat
        '
        Me.cboMat.BackColor = System.Drawing.SystemColors.Window
        Me.cboMat.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboMat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMat.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboMat.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboMat.Location = New System.Drawing.Point(87, 132)
        Me.cboMat.Name = "cboMat"
        Me.cboMat.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboMat.Size = New System.Drawing.Size(73, 24)
        Me.cboMat.TabIndex = 4
        '
        'cboNV
        '
        Me.cboNV.BackColor = System.Drawing.SystemColors.Window
        Me.cboNV.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboNV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboNV.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboNV.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboNV.Location = New System.Drawing.Point(8, 132)
        Me.cboNV.Name = "cboNV"
        Me.cboNV.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboNV.Size = New System.Drawing.Size(73, 24)
        Me.cboNV.TabIndex = 3
        '
        'cmdOK
        '
        Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdOK.Location = New System.Drawing.Point(192, 408)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdOK.Size = New System.Drawing.Size(73, 25)
        Me.cmdOK.TabIndex = 2
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(272, 408)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(73, 25)
        Me.cmdCancel.TabIndex = 1
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(8, 408)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(97, 25)
        Me.Command1.TabIndex = 0
        Me.Command1.Text = "Generate Jobs"
        Me.Command1.UseVisualStyleBackColor = False
        '
        'Toolbar1
        '
        Me.Toolbar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._Toolbar1_Button1, Me._Toolbar1_Button2, Me._Toolbar1_Button3, Me._Toolbar1_Button4, Me._Toolbar1_Button5})
        Me.Toolbar1.Location = New System.Drawing.Point(0, 0)
        Me.Toolbar1.Name = "Toolbar1"
        Me.Toolbar1.Size = New System.Drawing.Size(649, 25)
        Me.Toolbar1.TabIndex = 11
        '
        '_Toolbar1_Button1
        '
        Me._Toolbar1_Button1.AutoSize = False
        Me._Toolbar1_Button1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me._Toolbar1_Button1.Name = "_Toolbar1_Button1"
        Me._Toolbar1_Button1.Size = New System.Drawing.Size(19, 18)
        Me._Toolbar1_Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me._Toolbar1_Button1.ToolTipText = "Add School Record"
        '
        '_Toolbar1_Button2
        '
        Me._Toolbar1_Button2.AutoSize = False
        Me._Toolbar1_Button2.Name = "_Toolbar1_Button2"
        Me._Toolbar1_Button2.Size = New System.Drawing.Size(19, 18)
        '
        '_Toolbar1_Button3
        '
        Me._Toolbar1_Button3.AutoSize = False
        Me._Toolbar1_Button3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me._Toolbar1_Button3.Name = "_Toolbar1_Button3"
        Me._Toolbar1_Button3.Size = New System.Drawing.Size(19, 18)
        Me._Toolbar1_Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me._Toolbar1_Button3.ToolTipText = "Edit School Record"
        '
        '_Toolbar1_Button4
        '
        Me._Toolbar1_Button4.AutoSize = False
        Me._Toolbar1_Button4.Name = "_Toolbar1_Button4"
        Me._Toolbar1_Button4.Size = New System.Drawing.Size(19, 18)
        '
        '_Toolbar1_Button5
        '
        Me._Toolbar1_Button5.AutoSize = False
        Me._Toolbar1_Button5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me._Toolbar1_Button5.Name = "_Toolbar1_Button5"
        Me._Toolbar1_Button5.Size = New System.Drawing.Size(19, 18)
        Me._Toolbar1_Button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me._Toolbar1_Button5.ToolTipText = "Delete School Record"
        '
        'OfficeList
        '
        Me.OfficeList.BackColor = System.Drawing.SystemColors.Window
        Me.OfficeList.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me._OfficeList_ColumnHeader_1, Me._OfficeList_ColumnHeader_2, Me._OfficeList_ColumnHeader_3, Me._OfficeList_ColumnHeader_4, Me._OfficeList_ColumnHeader_5, Me._OfficeList_ColumnHeader_6, Me._OfficeList_ColumnHeader_7, Me._OfficeList_ColumnHeader_8, Me._OfficeList_ColumnHeader_9})
        Me.OfficeList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OfficeList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OfficeList.FullRowSelect = True
        Me.OfficeList.GridLines = True
        Me.OfficeList.Location = New System.Drawing.Point(8, 216)
        Me.OfficeList.Name = "OfficeList"
        Me.OfficeList.Size = New System.Drawing.Size(629, 185)
        Me.OfficeList.TabIndex = 22
        Me.OfficeList.UseCompatibleStateImageBehavior = False
        Me.OfficeList.View = System.Windows.Forms.View.Details
        '
        '_OfficeList_ColumnHeader_1
        '
        Me._OfficeList_ColumnHeader_1.Text = "Name"
        Me._OfficeList_ColumnHeader_1.Width = 170
        '
        '_OfficeList_ColumnHeader_2
        '
        Me._OfficeList_ColumnHeader_2.Text = "School"
        Me._OfficeList_ColumnHeader_2.Width = 170
        '
        '_OfficeList_ColumnHeader_3
        '
        Me._OfficeList_ColumnHeader_3.Text = "Grade"
        Me._OfficeList_ColumnHeader_3.Width = 170
        '
        '_OfficeList_ColumnHeader_4
        '
        Me._OfficeList_ColumnHeader_4.Text = "Semester"
        Me._OfficeList_ColumnHeader_4.Width = 170
        '
        '_OfficeList_ColumnHeader_5
        '
        Me._OfficeList_ColumnHeader_5.Text = "Battery"
        Me._OfficeList_ColumnHeader_5.Width = 170
        '
        '_OfficeList_ColumnHeader_6
        '
        Me._OfficeList_ColumnHeader_6.Text = "MAT"
        Me._OfficeList_ColumnHeader_6.Width = 170
        '
        '_OfficeList_ColumnHeader_7
        '
        Me._OfficeList_ColumnHeader_7.Text = "NV"
        Me._OfficeList_ColumnHeader_7.Width = 170
        '
        '_OfficeList_ColumnHeader_8
        '
        Me._OfficeList_ColumnHeader_8.Text = "LES"
        Me._OfficeList_ColumnHeader_8.Width = 170
        '
        '_OfficeList_ColumnHeader_9
        '
        Me._OfficeList_ColumnHeader_9.Text = "REN"
        Me._OfficeList_ColumnHeader_9.Width = 170
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(8, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(169, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Student Name:"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(8, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(73, 17)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Grade:"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(176, 65)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(46, 16)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "File:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(176, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(57, 21)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Semester:"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(8, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(73, 17)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "School:"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(242, 112)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(73, 17)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "REN:"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(84, 112)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(73, 17)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "MAT:"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(163, 112)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(73, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "LES:"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(8, 112)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(73, 17)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "NV:"
        '
        'frmOfficeTesting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(649, 435)
        Me.ControlBox = False
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.txtFile)
        Me.Controls.Add(Me.cboSemester)
        Me.Controls.Add(Me.cboGrade)
        Me.Controls.Add(Me.cboSchools)
        Me.Controls.Add(Me.cboRen)
        Me.Controls.Add(Me.cboLes)
        Me.Controls.Add(Me.cboMat)
        Me.Controls.Add(Me.cboNV)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.Command1)
        Me.Controls.Add(Me.Toolbar1)
        Me.Controls.Add(Me.OfficeList)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOfficeTesting"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Office Testing"
        Me.Toolbar1.ResumeLayout(False)
        Me.Toolbar1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region 
End Class