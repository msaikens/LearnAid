﻿Namespace Forms.ClaveForms
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class frmRules
        Inherits System.Windows.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.GroupBox1 = New System.Windows.Forms.GroupBox()
            Me.txtSD = New System.Windows.Forms.TextBox()
            Me.txtLD = New System.Windows.Forms.TextBox()
            Me.txtM = New System.Windows.Forms.TextBox()
            Me._txtAbr_0 = New System.Windows.Forms.TextBox()
            Me._txtAbr_1 = New System.Windows.Forms.TextBox()
            Me._txtAbr_2 = New System.Windows.Forms.TextBox()
            Me._txtAbr_3 = New System.Windows.Forms.TextBox()
            Me._txtAbr_4 = New System.Windows.Forms.TextBox()
            Me._txtAbr_5 = New System.Windows.Forms.TextBox()
            Me._txtAbr_6 = New System.Windows.Forms.TextBox()
            Me._txtAbr_7 = New System.Windows.Forms.TextBox()
            Me._txtAbr_8 = New System.Windows.Forms.TextBox()
            Me._Label3_3 = New System.Windows.Forms.Label()
            Me._Label3_2 = New System.Windows.Forms.Label()
            Me._Label3_1 = New System.Windows.Forms.Label()
            Me._Label2_0 = New System.Windows.Forms.Label()
            Me._Label2_1 = New System.Windows.Forms.Label()
            Me._Label2_2 = New System.Windows.Forms.Label()
            Me._Label2_3 = New System.Windows.Forms.Label()
            Me._Label2_4 = New System.Windows.Forms.Label()
            Me._Label2_5 = New System.Windows.Forms.Label()
            Me._Label2_6 = New System.Windows.Forms.Label()
            Me._Label2_7 = New System.Windows.Forms.Label()
            Me._Label2_8 = New System.Windows.Forms.Label()
            Me._Label3_0 = New System.Windows.Forms.Label()
            Me.btnCancel = New System.Windows.Forms.Button()
            Me.btnSave = New System.Windows.Forms.Button()
            Me.GroupBox1.SuspendLayout()
            Me.SuspendLayout()
            '
            'GroupBox1
            '
            Me.GroupBox1.Controls.Add(Me.txtSD)
            Me.GroupBox1.Controls.Add(Me.txtLD)
            Me.GroupBox1.Controls.Add(Me.txtM)
            Me.GroupBox1.Controls.Add(Me._txtAbr_0)
            Me.GroupBox1.Controls.Add(Me._txtAbr_1)
            Me.GroupBox1.Controls.Add(Me._txtAbr_2)
            Me.GroupBox1.Controls.Add(Me._txtAbr_3)
            Me.GroupBox1.Controls.Add(Me._txtAbr_4)
            Me.GroupBox1.Controls.Add(Me._txtAbr_5)
            Me.GroupBox1.Controls.Add(Me._txtAbr_6)
            Me.GroupBox1.Controls.Add(Me._txtAbr_7)
            Me.GroupBox1.Controls.Add(Me._txtAbr_8)
            Me.GroupBox1.Controls.Add(Me._Label3_3)
            Me.GroupBox1.Controls.Add(Me._Label3_2)
            Me.GroupBox1.Controls.Add(Me._Label3_1)
            Me.GroupBox1.Controls.Add(Me._Label2_0)
            Me.GroupBox1.Controls.Add(Me._Label2_1)
            Me.GroupBox1.Controls.Add(Me._Label2_2)
            Me.GroupBox1.Controls.Add(Me._Label2_3)
            Me.GroupBox1.Controls.Add(Me._Label2_4)
            Me.GroupBox1.Controls.Add(Me._Label2_5)
            Me.GroupBox1.Controls.Add(Me._Label2_6)
            Me.GroupBox1.Controls.Add(Me._Label2_7)
            Me.GroupBox1.Controls.Add(Me._Label2_8)
            Me.GroupBox1.Controls.Add(Me._Label3_0)
            Me.GroupBox1.Location = New System.Drawing.Point(12, 7)
            Me.GroupBox1.Name = "GroupBox1"
            Me.GroupBox1.Size = New System.Drawing.Size(355, 298)
            Me.GroupBox1.TabIndex = 0
            Me.GroupBox1.TabStop = False
            '
            'txtSD
            '
            Me.txtSD.AcceptsReturn = True
            Me.txtSD.BackColor = System.Drawing.SystemColors.Window
            Me.txtSD.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtSD.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtSD.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtSD.Location = New System.Drawing.Point(227, 76)
            Me.txtSD.MaxLength = 0
            Me.txtSD.Name = "txtSD"
            Me.txtSD.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtSD.Size = New System.Drawing.Size(64, 20)
            Me.txtSD.TabIndex = 20
            '
            'txtLD
            '
            Me.txtLD.AcceptsReturn = True
            Me.txtLD.BackColor = System.Drawing.SystemColors.Window
            Me.txtLD.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtLD.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtLD.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtLD.Location = New System.Drawing.Point(227, 135)
            Me.txtLD.MaxLength = 0
            Me.txtLD.Name = "txtLD"
            Me.txtLD.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtLD.Size = New System.Drawing.Size(64, 20)
            Me.txtLD.TabIndex = 22
            '
            'txtM
            '
            Me.txtM.AcceptsReturn = True
            Me.txtM.BackColor = System.Drawing.SystemColors.Window
            Me.txtM.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.txtM.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtM.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtM.Location = New System.Drawing.Point(227, 188)
            Me.txtM.MaxLength = 0
            Me.txtM.Name = "txtM"
            Me.txtM.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.txtM.Size = New System.Drawing.Size(64, 20)
            Me.txtM.TabIndex = 24
            '
            '_txtAbr_0
            '
            Me._txtAbr_0.AcceptsReturn = True
            Me._txtAbr_0.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_0.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_0.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_0.Location = New System.Drawing.Point(35, 47)
            Me._txtAbr_0.MaxLength = 0
            Me._txtAbr_0.Name = "_txtAbr_0"
            Me._txtAbr_0.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_0.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_0.TabIndex = 2
            '
            '_txtAbr_1
            '
            Me._txtAbr_1.AcceptsReturn = True
            Me._txtAbr_1.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_1.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_1.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_1.Location = New System.Drawing.Point(35, 73)
            Me._txtAbr_1.MaxLength = 0
            Me._txtAbr_1.Name = "_txtAbr_1"
            Me._txtAbr_1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_1.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_1.TabIndex = 4
            '
            '_txtAbr_2
            '
            Me._txtAbr_2.AcceptsReturn = True
            Me._txtAbr_2.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_2.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_2.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_2.Location = New System.Drawing.Point(35, 99)
            Me._txtAbr_2.MaxLength = 0
            Me._txtAbr_2.Name = "_txtAbr_2"
            Me._txtAbr_2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_2.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_2.TabIndex = 6
            '
            '_txtAbr_3
            '
            Me._txtAbr_3.AcceptsReturn = True
            Me._txtAbr_3.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_3.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_3.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_3.Location = New System.Drawing.Point(35, 125)
            Me._txtAbr_3.MaxLength = 0
            Me._txtAbr_3.Name = "_txtAbr_3"
            Me._txtAbr_3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_3.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_3.TabIndex = 8
            '
            '_txtAbr_4
            '
            Me._txtAbr_4.AcceptsReturn = True
            Me._txtAbr_4.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_4.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_4.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_4.Location = New System.Drawing.Point(35, 151)
            Me._txtAbr_4.MaxLength = 0
            Me._txtAbr_4.Name = "_txtAbr_4"
            Me._txtAbr_4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_4.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_4.TabIndex = 10
            '
            '_txtAbr_5
            '
            Me._txtAbr_5.AcceptsReturn = True
            Me._txtAbr_5.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_5.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_5.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_5.Location = New System.Drawing.Point(35, 177)
            Me._txtAbr_5.MaxLength = 0
            Me._txtAbr_5.Name = "_txtAbr_5"
            Me._txtAbr_5.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_5.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_5.TabIndex = 12
            '
            '_txtAbr_6
            '
            Me._txtAbr_6.AcceptsReturn = True
            Me._txtAbr_6.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_6.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_6.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_6.Location = New System.Drawing.Point(35, 203)
            Me._txtAbr_6.MaxLength = 0
            Me._txtAbr_6.Name = "_txtAbr_6"
            Me._txtAbr_6.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_6.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_6.TabIndex = 14
            '
            '_txtAbr_7
            '
            Me._txtAbr_7.AcceptsReturn = True
            Me._txtAbr_7.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_7.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_7.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_7.Location = New System.Drawing.Point(35, 229)
            Me._txtAbr_7.MaxLength = 0
            Me._txtAbr_7.Name = "_txtAbr_7"
            Me._txtAbr_7.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_7.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_7.TabIndex = 16
            '
            '_txtAbr_8
            '
            Me._txtAbr_8.AcceptsReturn = True
            Me._txtAbr_8.BackColor = System.Drawing.SystemColors.Window
            Me._txtAbr_8.Cursor = System.Windows.Forms.Cursors.IBeam
            Me._txtAbr_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._txtAbr_8.ForeColor = System.Drawing.SystemColors.WindowText
            Me._txtAbr_8.Location = New System.Drawing.Point(35, 255)
            Me._txtAbr_8.MaxLength = 0
            Me._txtAbr_8.Name = "_txtAbr_8"
            Me._txtAbr_8.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._txtAbr_8.Size = New System.Drawing.Size(68, 20)
            Me._txtAbr_8.TabIndex = 18
            '
            '_Label3_3
            '
            Me._Label3_3.BackColor = System.Drawing.SystemColors.Control
            Me._Label3_3.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label3_3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label3_3.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label3_3.Location = New System.Drawing.Point(191, 111)
            Me._Label3_3.Name = "_Label3_3"
            Me._Label3_3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label3_3.Size = New System.Drawing.Size(136, 19)
            Me._Label3_3.TabIndex = 21
            Me._Label3_3.Text = "Low Deviation"
            Me._Label3_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
            '
            '_Label3_2
            '
            Me._Label3_2.BackColor = System.Drawing.SystemColors.Control
            Me._Label3_2.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label3_2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label3_2.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label3_2.Location = New System.Drawing.Point(191, 164)
            Me._Label3_2.Name = "_Label3_2"
            Me._Label3_2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label3_2.Size = New System.Drawing.Size(136, 19)
            Me._Label3_2.TabIndex = 23
            Me._Label3_2.Text = "Media"
            Me._Label3_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
            '
            '_Label3_1
            '
            Me._Label3_1.BackColor = System.Drawing.SystemColors.Control
            Me._Label3_1.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label3_1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label3_1.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label3_1.Location = New System.Drawing.Point(191, 54)
            Me._Label3_1.Name = "_Label3_1"
            Me._Label3_1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label3_1.Size = New System.Drawing.Size(136, 19)
            Me._Label3_1.TabIndex = 19
            Me._Label3_1.Text = "Standard Deviation"
            Me._Label3_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
            '
            '_Label2_0
            '
            Me._Label2_0.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_0.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_0.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_0.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_0.Location = New System.Drawing.Point(19, 49)
            Me._Label2_0.Name = "_Label2_0"
            Me._Label2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_0.Size = New System.Drawing.Size(10, 16)
            Me._Label2_0.TabIndex = 1
            Me._Label2_0.Text = "1"
            '
            '_Label2_1
            '
            Me._Label2_1.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_1.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_1.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_1.Location = New System.Drawing.Point(19, 75)
            Me._Label2_1.Name = "_Label2_1"
            Me._Label2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_1.Size = New System.Drawing.Size(10, 16)
            Me._Label2_1.TabIndex = 3
            Me._Label2_1.Text = "2"
            '
            '_Label2_2
            '
            Me._Label2_2.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_2.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_2.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_2.Location = New System.Drawing.Point(19, 101)
            Me._Label2_2.Name = "_Label2_2"
            Me._Label2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_2.Size = New System.Drawing.Size(10, 16)
            Me._Label2_2.TabIndex = 5
            Me._Label2_2.Text = "3"
            '
            '_Label2_3
            '
            Me._Label2_3.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_3.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_3.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_3.Location = New System.Drawing.Point(19, 127)
            Me._Label2_3.Name = "_Label2_3"
            Me._Label2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_3.Size = New System.Drawing.Size(10, 16)
            Me._Label2_3.TabIndex = 7
            Me._Label2_3.Text = "4"
            '
            '_Label2_4
            '
            Me._Label2_4.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_4.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_4.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_4.Location = New System.Drawing.Point(19, 153)
            Me._Label2_4.Name = "_Label2_4"
            Me._Label2_4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_4.Size = New System.Drawing.Size(10, 16)
            Me._Label2_4.TabIndex = 9
            Me._Label2_4.Text = "5"
            '
            '_Label2_5
            '
            Me._Label2_5.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_5.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_5.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_5.Location = New System.Drawing.Point(19, 179)
            Me._Label2_5.Name = "_Label2_5"
            Me._Label2_5.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_5.Size = New System.Drawing.Size(10, 16)
            Me._Label2_5.TabIndex = 11
            Me._Label2_5.Text = "6"
            '
            '_Label2_6
            '
            Me._Label2_6.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_6.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_6.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_6.Location = New System.Drawing.Point(19, 205)
            Me._Label2_6.Name = "_Label2_6"
            Me._Label2_6.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_6.Size = New System.Drawing.Size(10, 16)
            Me._Label2_6.TabIndex = 13
            Me._Label2_6.Text = "7"
            '
            '_Label2_7
            '
            Me._Label2_7.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_7.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_7.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_7.Location = New System.Drawing.Point(19, 231)
            Me._Label2_7.Name = "_Label2_7"
            Me._Label2_7.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_7.Size = New System.Drawing.Size(10, 16)
            Me._Label2_7.TabIndex = 15
            Me._Label2_7.Text = "8"
            '
            '_Label2_8
            '
            Me._Label2_8.BackColor = System.Drawing.SystemColors.Control
            Me._Label2_8.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label2_8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label2_8.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label2_8.Location = New System.Drawing.Point(19, 257)
            Me._Label2_8.Name = "_Label2_8"
            Me._Label2_8.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label2_8.Size = New System.Drawing.Size(10, 16)
            Me._Label2_8.TabIndex = 17
            Me._Label2_8.Text = "9"
            '
            '_Label3_0
            '
            Me._Label3_0.BackColor = System.Drawing.SystemColors.Control
            Me._Label3_0.Cursor = System.Windows.Forms.Cursors.Default
            Me._Label3_0.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me._Label3_0.ForeColor = System.Drawing.SystemColors.ControlText
            Me._Label3_0.Location = New System.Drawing.Point(27, 17)
            Me._Label3_0.Name = "_Label3_0"
            Me._Label3_0.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me._Label3_0.Size = New System.Drawing.Size(136, 19)
            Me._Label3_0.TabIndex = 0
            Me._Label3_0.Text = "Stanine to"
            '
            'btnCancel
            '
            Me.btnCancel.Location = New System.Drawing.Point(290, 311)
            Me.btnCancel.Name = "btnCancel"
            Me.btnCancel.Size = New System.Drawing.Size(75, 23)
            Me.btnCancel.TabIndex = 2
            Me.btnCancel.Text = "Cancel"
            Me.btnCancel.UseVisualStyleBackColor = True
            '
            'btnSave
            '
            Me.btnSave.Location = New System.Drawing.Point(209, 311)
            Me.btnSave.Name = "btnSave"
            Me.btnSave.Size = New System.Drawing.Size(75, 23)
            Me.btnSave.TabIndex = 1
            Me.btnSave.Text = "Save"
            Me.btnSave.UseVisualStyleBackColor = True
            '
            'frmRules
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(377, 347)
            Me.Controls.Add(Me.btnCancel)
            Me.Controls.Add(Me.btnSave)
            Me.Controls.Add(Me.GroupBox1)
            Me.Name = "frmRules"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Edit Rules"
            Me.GroupBox1.ResumeLayout(False)
            Me.GroupBox1.PerformLayout()
            Me.ResumeLayout(False)

        End Sub
        Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
        Public WithEvents txtSD As System.Windows.Forms.TextBox
        Public WithEvents txtLD As System.Windows.Forms.TextBox
        Public WithEvents txtM As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_0 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_1 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_2 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_3 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_4 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_5 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_6 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_7 As System.Windows.Forms.TextBox
        Public WithEvents _txtAbr_8 As System.Windows.Forms.TextBox
        Public WithEvents _Label3_3 As System.Windows.Forms.Label
        Public WithEvents _Label3_2 As System.Windows.Forms.Label
        Public WithEvents _Label3_1 As System.Windows.Forms.Label
        Public WithEvents _Label2_0 As System.Windows.Forms.Label
        Public WithEvents _Label2_1 As System.Windows.Forms.Label
        Public WithEvents _Label2_2 As System.Windows.Forms.Label
        Public WithEvents _Label2_3 As System.Windows.Forms.Label
        Public WithEvents _Label2_4 As System.Windows.Forms.Label
        Public WithEvents _Label2_5 As System.Windows.Forms.Label
        Public WithEvents _Label2_6 As System.Windows.Forms.Label
        Public WithEvents _Label2_7 As System.Windows.Forms.Label
        Public WithEvents _Label2_8 As System.Windows.Forms.Label
        Public WithEvents _Label3_0 As System.Windows.Forms.Label
        Friend WithEvents btnCancel As System.Windows.Forms.Button
        Friend WithEvents btnSave As System.Windows.Forms.Button
    End Class
End Namespace