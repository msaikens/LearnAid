<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmPrePost
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Command15 As System.Windows.Forms.Button
	Public WithEvents TxtNV As System.Windows.Forms.TextBox
	Public WithEvents txtRen As System.Windows.Forms.TextBox
	Public WithEvents txtLes As System.Windows.Forms.TextBox
	Public WithEvents txtEstPre As System.Windows.Forms.TextBox
	Public WithEvents txtMat As System.Windows.Forms.TextBox
	Public WithEvents Label26 As System.Windows.Forms.Label
	Public WithEvents Label25 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label23 As System.Windows.Forms.Label
	Public WithEvents Label22 As System.Windows.Forms.Label
	Public WithEvents Frame7 As System.Windows.Forms.GroupBox
	Public WithEvents cboSchools2 As System.Windows.Forms.ComboBox
	Public WithEvents txtPOSTSem As System.Windows.Forms.TextBox
	Public WithEvents txtPREsem As System.Windows.Forms.TextBox
	Public WithEvents txtPOSTHasta As System.Windows.Forms.TextBox
	Public WithEvents txtPOSTDesde As System.Windows.Forms.TextBox
	Public WithEvents txtPREHasta As System.Windows.Forms.TextBox
	Public WithEvents txtPREDesde As System.Windows.Forms.TextBox
	Public WithEvents cboMetodo As System.Windows.Forms.ComboBox
	Public WithEvents cboYear As System.Windows.Forms.ComboBox
	Public WithEvents Label27 As System.Windows.Forms.Label
	Public WithEvents Label24 As System.Windows.Forms.Label
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label18 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents lblPrePost As System.Windows.Forms.Label
	Public WithEvents Label21 As System.Windows.Forms.Label
	Public WithEvents Label20 As System.Windows.Forms.Label
	Public WithEvents Frame6 As System.Windows.Forms.GroupBox
	Public WithEvents cmdPrint As System.Windows.Forms.Button
	Public WithEvents Command14 As System.Windows.Forms.Button
	Public WithEvents Command13 As System.Windows.Forms.Button
	Public WithEvents lblStatus2 As System.Windows.Forms.Label
	Public WithEvents Frame5 As System.Windows.Forms.GroupBox
	Public WithEvents txtSemPost As System.Windows.Forms.TextBox
	Public WithEvents txtyearPost As System.Windows.Forms.TextBox
	Public WithEvents Command4 As System.Windows.Forms.Button
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Frame4 As System.Windows.Forms.GroupBox
	Public WithEvents txtSemPRE As System.Windows.Forms.TextBox
	Public WithEvents txtYearPRE As System.Windows.Forms.TextBox
	Public WithEvents Command2 As System.Windows.Forms.Button
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
	Public WithEvents txtDatosDup As System.Windows.Forms.TextBox
	Public WithEvents txtDatosNoMatch As System.Windows.Forms.TextBox
	Public WithEvents txtDatosPost As System.Windows.Forms.TextBox
	Public WithEvents txtDatosPre As System.Windows.Forms.TextBox
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents cboSchools As System.Windows.Forms.ComboBox
	Public WithEvents Command12 As System.Windows.Forms.Button
	Public WithEvents Command11 As System.Windows.Forms.Button
	Public WithEvents Command10 As System.Windows.Forms.Button
	Public WithEvents Command9 As System.Windows.Forms.Button
	Public WithEvents Command8 As System.Windows.Forms.Button
	Public WithEvents Command7 As System.Windows.Forms.Button
	Public WithEvents Command6 As System.Windows.Forms.Button
	Public WithEvents Command5 As System.Windows.Forms.Button
	Public WithEvents Command3 As System.Windows.Forms.Button
	Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents lblStatus As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents frmPrePost As System.Windows.Forms.GroupBox
	Public WithEvents Label17 As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPrePost))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Frame7 = New System.Windows.Forms.GroupBox
		Me.Command15 = New System.Windows.Forms.Button
		Me.TxtNV = New System.Windows.Forms.TextBox
		Me.txtRen = New System.Windows.Forms.TextBox
		Me.txtLes = New System.Windows.Forms.TextBox
		Me.txtEstPre = New System.Windows.Forms.TextBox
		Me.txtMat = New System.Windows.Forms.TextBox
		Me.Label26 = New System.Windows.Forms.Label
		Me.Label25 = New System.Windows.Forms.Label
		Me.Label16 = New System.Windows.Forms.Label
		Me.Label23 = New System.Windows.Forms.Label
		Me.Label22 = New System.Windows.Forms.Label
		Me.Frame6 = New System.Windows.Forms.GroupBox
		Me.cboSchools2 = New System.Windows.Forms.ComboBox
		Me.txtPOSTSem = New System.Windows.Forms.TextBox
		Me.txtPREsem = New System.Windows.Forms.TextBox
		Me.txtPOSTHasta = New System.Windows.Forms.TextBox
		Me.txtPOSTDesde = New System.Windows.Forms.TextBox
		Me.txtPREHasta = New System.Windows.Forms.TextBox
		Me.txtPREDesde = New System.Windows.Forms.TextBox
		Me.cboMetodo = New System.Windows.Forms.ComboBox
		Me.cboYear = New System.Windows.Forms.ComboBox
		Me.Label27 = New System.Windows.Forms.Label
		Me.Label24 = New System.Windows.Forms.Label
		Me.Label19 = New System.Windows.Forms.Label
		Me.Label18 = New System.Windows.Forms.Label
		Me.Label15 = New System.Windows.Forms.Label
		Me.Label14 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.lblPrePost = New System.Windows.Forms.Label
		Me.Label21 = New System.Windows.Forms.Label
		Me.Label20 = New System.Windows.Forms.Label
		Me.Frame5 = New System.Windows.Forms.GroupBox
		Me.cmdPrint = New System.Windows.Forms.Button
		Me.Command14 = New System.Windows.Forms.Button
		Me.Command13 = New System.Windows.Forms.Button
		Me.lblStatus2 = New System.Windows.Forms.Label
        Me.frmPrePost = New System.Windows.Forms.GroupBox
		Me.Frame4 = New System.Windows.Forms.GroupBox
		Me.txtSemPost = New System.Windows.Forms.TextBox
		Me.txtyearPost = New System.Windows.Forms.TextBox
		Me.Command4 = New System.Windows.Forms.Button
		Me.Label13 = New System.Windows.Forms.Label
		Me.Label12 = New System.Windows.Forms.Label
		Me.Frame3 = New System.Windows.Forms.GroupBox
		Me.txtSemPRE = New System.Windows.Forms.TextBox
		Me.txtYearPRE = New System.Windows.Forms.TextBox
		Me.Command2 = New System.Windows.Forms.Button
		Me.Label9 = New System.Windows.Forms.Label
		Me.Label5 = New System.Windows.Forms.Label
		Me.Frame2 = New System.Windows.Forms.GroupBox
		Me.txtDatosDup = New System.Windows.Forms.TextBox
		Me.txtDatosNoMatch = New System.Windows.Forms.TextBox
		Me.txtDatosPost = New System.Windows.Forms.TextBox
		Me.txtDatosPre = New System.Windows.Forms.TextBox
		Me.Label7 = New System.Windows.Forms.Label
		Me.Label6 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.Frame1 = New System.Windows.Forms.GroupBox
		Me.cboSchools = New System.Windows.Forms.ComboBox
		Me.Command12 = New System.Windows.Forms.Button
		Me.Command11 = New System.Windows.Forms.Button
		Me.Command10 = New System.Windows.Forms.Button
		Me.Command9 = New System.Windows.Forms.Button
		Me.Command8 = New System.Windows.Forms.Button
		Me.Command7 = New System.Windows.Forms.Button
		Me.Command6 = New System.Windows.Forms.Button
		Me.Command5 = New System.Windows.Forms.Button
		Me.Command3 = New System.Windows.Forms.Button
		Me.Command1 = New System.Windows.Forms.Button
		Me.Label2 = New System.Windows.Forms.Label
		Me.cmdClose = New System.Windows.Forms.Button
		Me.Label10 = New System.Windows.Forms.Label
		Me.lblStatus = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label17 = New System.Windows.Forms.Label
		Me.Frame7.SuspendLayout()
		Me.Frame6.SuspendLayout()
		Me.Frame5.SuspendLayout()
        'Me.frmPrePost_Renamed.SuspendLayout()
		Me.Frame4.SuspendLayout()
		Me.Frame3.SuspendLayout()
		Me.Frame2.SuspendLayout()
		Me.Frame1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.Text = "Pre/Post Form"
		Me.ClientSize = New System.Drawing.Size(398, 414)
		Me.Location = New System.Drawing.Point(4, 30)
		Me.MaximizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmPrePost"
		Me.Frame7.Text = "Total Datos Procesados:"
		Me.Frame7.Size = New System.Drawing.Size(392, 100)
		Me.Frame7.Location = New System.Drawing.Point(0, 304)
		Me.Frame7.TabIndex = 43
		Me.Frame7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame7.BackColor = System.Drawing.SystemColors.Control
		Me.Frame7.Enabled = True
		Me.Frame7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame7.Visible = True
		Me.Frame7.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame7.Name = "Frame7"
		Me.Command15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command15.Text = "Close"
		Me.Command15.Size = New System.Drawing.Size(64, 28)
		Me.Command15.Location = New System.Drawing.Point(320, 64)
		Me.Command15.TabIndex = 77
		Me.Command15.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command15.BackColor = System.Drawing.SystemColors.Control
		Me.Command15.CausesValidation = True
		Me.Command15.Enabled = True
		Me.Command15.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command15.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command15.TabStop = True
		Me.Command15.Name = "Command15"
		Me.TxtNV.AutoSize = False
		Me.TxtNV.Size = New System.Drawing.Size(43, 21)
		Me.TxtNV.Location = New System.Drawing.Point(344, 16)
		Me.TxtNV.ReadOnly = True
		Me.TxtNV.TabIndex = 70
		Me.TxtNV.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TxtNV.AcceptsReturn = True
		Me.TxtNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.TxtNV.BackColor = System.Drawing.SystemColors.Window
		Me.TxtNV.CausesValidation = True
		Me.TxtNV.Enabled = True
		Me.TxtNV.ForeColor = System.Drawing.SystemColors.WindowText
		Me.TxtNV.HideSelection = True
		Me.TxtNV.Maxlength = 0
		Me.TxtNV.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.TxtNV.MultiLine = False
		Me.TxtNV.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.TxtNV.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.TxtNV.TabStop = True
		Me.TxtNV.Visible = True
		Me.TxtNV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.TxtNV.Name = "TxtNV"
		Me.txtRen.AutoSize = False
		Me.txtRen.Size = New System.Drawing.Size(43, 21)
		Me.txtRen.Location = New System.Drawing.Point(272, 16)
		Me.txtRen.ReadOnly = True
		Me.txtRen.TabIndex = 68
		Me.txtRen.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtRen.AcceptsReturn = True
		Me.txtRen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtRen.BackColor = System.Drawing.SystemColors.Window
		Me.txtRen.CausesValidation = True
		Me.txtRen.Enabled = True
		Me.txtRen.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtRen.HideSelection = True
		Me.txtRen.Maxlength = 0
		Me.txtRen.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtRen.MultiLine = False
		Me.txtRen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtRen.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtRen.TabStop = True
		Me.txtRen.Visible = True
		Me.txtRen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtRen.Name = "txtRen"
		Me.txtLes.AutoSize = False
		Me.txtLes.Size = New System.Drawing.Size(43, 21)
		Me.txtLes.Location = New System.Drawing.Point(200, 16)
		Me.txtLes.ReadOnly = True
		Me.txtLes.TabIndex = 48
		Me.txtLes.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtLes.AcceptsReturn = True
		Me.txtLes.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtLes.BackColor = System.Drawing.SystemColors.Window
		Me.txtLes.CausesValidation = True
		Me.txtLes.Enabled = True
		Me.txtLes.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtLes.HideSelection = True
		Me.txtLes.Maxlength = 0
		Me.txtLes.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtLes.MultiLine = False
		Me.txtLes.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtLes.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtLes.TabStop = True
		Me.txtLes.Visible = True
		Me.txtLes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtLes.Name = "txtLes"
		Me.txtEstPre.AutoSize = False
		Me.txtEstPre.Size = New System.Drawing.Size(44, 21)
		Me.txtEstPre.Location = New System.Drawing.Point(60, 15)
		Me.txtEstPre.ReadOnly = True
		Me.txtEstPre.TabIndex = 45
		Me.txtEstPre.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtEstPre.AcceptsReturn = True
		Me.txtEstPre.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtEstPre.BackColor = System.Drawing.SystemColors.Window
		Me.txtEstPre.CausesValidation = True
		Me.txtEstPre.Enabled = True
		Me.txtEstPre.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtEstPre.HideSelection = True
		Me.txtEstPre.Maxlength = 0
		Me.txtEstPre.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtEstPre.MultiLine = False
		Me.txtEstPre.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtEstPre.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtEstPre.TabStop = True
		Me.txtEstPre.Visible = True
		Me.txtEstPre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtEstPre.Name = "txtEstPre"
		Me.txtMat.AutoSize = False
		Me.txtMat.Size = New System.Drawing.Size(35, 21)
		Me.txtMat.Location = New System.Drawing.Point(136, 16)
		Me.txtMat.ReadOnly = True
		Me.txtMat.TabIndex = 44
		Me.txtMat.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtMat.AcceptsReturn = True
		Me.txtMat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtMat.BackColor = System.Drawing.SystemColors.Window
		Me.txtMat.CausesValidation = True
		Me.txtMat.Enabled = True
		Me.txtMat.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtMat.HideSelection = True
		Me.txtMat.Maxlength = 0
		Me.txtMat.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtMat.MultiLine = False
		Me.txtMat.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtMat.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtMat.TabStop = True
		Me.txtMat.Visible = True
		Me.txtMat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtMat.Name = "txtMat"
		Me.Label26.Text = "NV:"
		Me.Label26.Size = New System.Drawing.Size(29, 21)
		Me.Label26.Location = New System.Drawing.Point(320, 16)
		Me.Label26.TabIndex = 71
		Me.Label26.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label26.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label26.BackColor = System.Drawing.SystemColors.Control
		Me.Label26.Enabled = True
		Me.Label26.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label26.UseMnemonic = True
		Me.Label26.Visible = True
		Me.Label26.AutoSize = False
		Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label26.Name = "Label26"
		Me.Label25.Text = "Ren:"
		Me.Label25.Size = New System.Drawing.Size(29, 21)
		Me.Label25.Location = New System.Drawing.Point(248, 16)
		Me.Label25.TabIndex = 69
		Me.Label25.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label25.BackColor = System.Drawing.SystemColors.Control
		Me.Label25.Enabled = True
		Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label25.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label25.UseMnemonic = True
		Me.Label25.Visible = True
		Me.Label25.AutoSize = False
		Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label25.Name = "Label25"
		Me.Label16.Text = "Les:"
		Me.Label16.Size = New System.Drawing.Size(29, 21)
		Me.Label16.Location = New System.Drawing.Point(176, 16)
		Me.Label16.TabIndex = 49
		Me.Label16.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label16.BackColor = System.Drawing.SystemColors.Control
		Me.Label16.Enabled = True
		Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label16.UseMnemonic = True
		Me.Label16.Visible = True
		Me.Label16.AutoSize = False
		Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label16.Name = "Label16"
		Me.Label23.Text = "# Est. Pre:"
		Me.Label23.Size = New System.Drawing.Size(61, 21)
		Me.Label23.Location = New System.Drawing.Point(5, 20)
		Me.Label23.TabIndex = 47
		Me.Label23.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label23.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label23.BackColor = System.Drawing.SystemColors.Control
		Me.Label23.Enabled = True
		Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label23.UseMnemonic = True
		Me.Label23.Visible = True
		Me.Label23.AutoSize = False
		Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label23.Name = "Label23"
		Me.Label22.Text = "Mat:"
		Me.Label22.Size = New System.Drawing.Size(36, 21)
		Me.Label22.Location = New System.Drawing.Point(109, 16)
		Me.Label22.TabIndex = 46
		Me.Label22.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label22.BackColor = System.Drawing.SystemColors.Control
		Me.Label22.Enabled = True
		Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label22.UseMnemonic = True
		Me.Label22.Visible = True
		Me.Label22.AutoSize = False
		Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label22.Name = "Label22"
		Me.Frame6.Text = "1er Paso: PRE"
		Me.Frame6.Size = New System.Drawing.Size(393, 169)
		Me.Frame6.Location = New System.Drawing.Point(0, 32)
		Me.Frame6.TabIndex = 39
		Me.Frame6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame6.BackColor = System.Drawing.SystemColors.Control
		Me.Frame6.Enabled = True
		Me.Frame6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame6.Visible = True
		Me.Frame6.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame6.Name = "Frame6"
		Me.cboSchools2.Size = New System.Drawing.Size(209, 20)
		Me.cboSchools2.Location = New System.Drawing.Point(108, 80)
		Me.cboSchools2.TabIndex = 74
		Me.cboSchools2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboSchools2.BackColor = System.Drawing.SystemColors.Window
		Me.cboSchools2.CausesValidation = True
		Me.cboSchools2.Enabled = True
		Me.cboSchools2.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cboSchools2.IntegralHeight = True
		Me.cboSchools2.Cursor = System.Windows.Forms.Cursors.Default
		Me.cboSchools2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cboSchools2.Sorted = False
		Me.cboSchools2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cboSchools2.TabStop = True
		Me.cboSchools2.Visible = True
		Me.cboSchools2.Name = "cboSchools2"
		Me.txtPOSTSem.AutoSize = False
		Me.txtPOSTSem.Size = New System.Drawing.Size(41, 19)
		Me.txtPOSTSem.Location = New System.Drawing.Point(348, 136)
		Me.txtPOSTSem.TabIndex = 66
		Me.txtPOSTSem.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPOSTSem.AcceptsReturn = True
		Me.txtPOSTSem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPOSTSem.BackColor = System.Drawing.SystemColors.Window
		Me.txtPOSTSem.CausesValidation = True
		Me.txtPOSTSem.Enabled = True
		Me.txtPOSTSem.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPOSTSem.HideSelection = True
		Me.txtPOSTSem.ReadOnly = False
		Me.txtPOSTSem.Maxlength = 0
		Me.txtPOSTSem.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPOSTSem.MultiLine = False
		Me.txtPOSTSem.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPOSTSem.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPOSTSem.TabStop = True
		Me.txtPOSTSem.Visible = True
		Me.txtPOSTSem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPOSTSem.Name = "txtPOSTSem"
		Me.txtPREsem.AutoSize = False
		Me.txtPREsem.Size = New System.Drawing.Size(41, 19)
		Me.txtPREsem.Location = New System.Drawing.Point(348, 112)
		Me.txtPREsem.TabIndex = 64
		Me.txtPREsem.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPREsem.AcceptsReturn = True
		Me.txtPREsem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPREsem.BackColor = System.Drawing.SystemColors.Window
		Me.txtPREsem.CausesValidation = True
		Me.txtPREsem.Enabled = True
		Me.txtPREsem.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPREsem.HideSelection = True
		Me.txtPREsem.ReadOnly = False
		Me.txtPREsem.Maxlength = 0
		Me.txtPREsem.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPREsem.MultiLine = False
		Me.txtPREsem.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPREsem.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPREsem.TabStop = True
		Me.txtPREsem.Visible = True
		Me.txtPREsem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPREsem.Name = "txtPREsem"
		Me.txtPOSTHasta.AutoSize = False
		Me.txtPOSTHasta.Size = New System.Drawing.Size(87, 19)
		Me.txtPOSTHasta.Location = New System.Drawing.Point(216, 136)
		Me.txtPOSTHasta.TabIndex = 61
		Me.txtPOSTHasta.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPOSTHasta.AcceptsReturn = True
		Me.txtPOSTHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPOSTHasta.BackColor = System.Drawing.SystemColors.Window
		Me.txtPOSTHasta.CausesValidation = True
		Me.txtPOSTHasta.Enabled = True
		Me.txtPOSTHasta.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPOSTHasta.HideSelection = True
		Me.txtPOSTHasta.ReadOnly = False
		Me.txtPOSTHasta.Maxlength = 0
		Me.txtPOSTHasta.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPOSTHasta.MultiLine = False
		Me.txtPOSTHasta.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPOSTHasta.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPOSTHasta.TabStop = True
		Me.txtPOSTHasta.Visible = True
		Me.txtPOSTHasta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPOSTHasta.Name = "txtPOSTHasta"
		Me.txtPOSTDesde.AutoSize = False
		Me.txtPOSTDesde.Size = New System.Drawing.Size(87, 19)
		Me.txtPOSTDesde.Location = New System.Drawing.Point(80, 136)
		Me.txtPOSTDesde.TabIndex = 60
		Me.txtPOSTDesde.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPOSTDesde.AcceptsReturn = True
		Me.txtPOSTDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPOSTDesde.BackColor = System.Drawing.SystemColors.Window
		Me.txtPOSTDesde.CausesValidation = True
		Me.txtPOSTDesde.Enabled = True
		Me.txtPOSTDesde.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPOSTDesde.HideSelection = True
		Me.txtPOSTDesde.ReadOnly = False
		Me.txtPOSTDesde.Maxlength = 0
		Me.txtPOSTDesde.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPOSTDesde.MultiLine = False
		Me.txtPOSTDesde.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPOSTDesde.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPOSTDesde.TabStop = True
		Me.txtPOSTDesde.Visible = True
		Me.txtPOSTDesde.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPOSTDesde.Name = "txtPOSTDesde"
		Me.txtPREHasta.AutoSize = False
		Me.txtPREHasta.Size = New System.Drawing.Size(87, 19)
		Me.txtPREHasta.Location = New System.Drawing.Point(216, 112)
		Me.txtPREHasta.TabIndex = 57
		Me.txtPREHasta.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPREHasta.AcceptsReturn = True
		Me.txtPREHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPREHasta.BackColor = System.Drawing.SystemColors.Window
		Me.txtPREHasta.CausesValidation = True
		Me.txtPREHasta.Enabled = True
		Me.txtPREHasta.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPREHasta.HideSelection = True
		Me.txtPREHasta.ReadOnly = False
		Me.txtPREHasta.Maxlength = 0
		Me.txtPREHasta.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPREHasta.MultiLine = False
		Me.txtPREHasta.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPREHasta.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPREHasta.TabStop = True
		Me.txtPREHasta.Visible = True
		Me.txtPREHasta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPREHasta.Name = "txtPREHasta"
		Me.txtPREDesde.AutoSize = False
		Me.txtPREDesde.Size = New System.Drawing.Size(87, 19)
		Me.txtPREDesde.Location = New System.Drawing.Point(80, 112)
		Me.txtPREDesde.TabIndex = 56
		Me.txtPREDesde.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPREDesde.AcceptsReturn = True
		Me.txtPREDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPREDesde.BackColor = System.Drawing.SystemColors.Window
		Me.txtPREDesde.CausesValidation = True
		Me.txtPREDesde.Enabled = True
		Me.txtPREDesde.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPREDesde.HideSelection = True
		Me.txtPREDesde.ReadOnly = False
		Me.txtPREDesde.Maxlength = 0
		Me.txtPREDesde.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPREDesde.MultiLine = False
		Me.txtPREDesde.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPREDesde.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPREDesde.TabStop = True
		Me.txtPREDesde.Visible = True
		Me.txtPREDesde.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPREDesde.Name = "txtPREDesde"
		Me.cboMetodo.Size = New System.Drawing.Size(177, 21)
		Me.cboMetodo.Location = New System.Drawing.Point(200, 24)
		Me.cboMetodo.TabIndex = 52
		Me.cboMetodo.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboMetodo.BackColor = System.Drawing.SystemColors.Window
		Me.cboMetodo.CausesValidation = True
		Me.cboMetodo.Enabled = True
		Me.cboMetodo.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cboMetodo.IntegralHeight = True
		Me.cboMetodo.Cursor = System.Windows.Forms.Cursors.Default
		Me.cboMetodo.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cboMetodo.Sorted = False
		Me.cboMetodo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cboMetodo.TabStop = True
		Me.cboMetodo.Visible = True
		Me.cboMetodo.Name = "cboMetodo"
		Me.cboYear.Size = New System.Drawing.Size(81, 21)
		Me.cboYear.Location = New System.Drawing.Point(56, 24)
		Me.cboYear.TabIndex = 50
		Me.cboYear.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboYear.BackColor = System.Drawing.SystemColors.Window
		Me.cboYear.CausesValidation = True
		Me.cboYear.Enabled = True
		Me.cboYear.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cboYear.IntegralHeight = True
		Me.cboYear.Cursor = System.Windows.Forms.Cursors.Default
		Me.cboYear.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cboYear.Sorted = False
		Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cboYear.TabStop = True
		Me.cboYear.Visible = True
		Me.cboYear.Name = "cboYear"
		Me.Label27.Text = "Seleccione Colegio:"
		Me.Label27.Size = New System.Drawing.Size(107, 16)
		Me.Label27.Location = New System.Drawing.Point(8, 80)
		Me.Label27.TabIndex = 75
		Me.Label27.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label27.BackColor = System.Drawing.SystemColors.Control
		Me.Label27.Enabled = True
		Me.Label27.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label27.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label27.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label27.UseMnemonic = True
		Me.Label27.Visible = True
		Me.Label27.AutoSize = False
		Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label27.Name = "Label27"
		Me.Label24.Text = "Sem:"
		Me.Label24.Size = New System.Drawing.Size(33, 17)
		Me.Label24.Location = New System.Drawing.Point(312, 136)
		Me.Label24.TabIndex = 67
		Me.Label24.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label24.BackColor = System.Drawing.SystemColors.Control
		Me.Label24.Enabled = True
		Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label24.UseMnemonic = True
		Me.Label24.Visible = True
		Me.Label24.AutoSize = False
		Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label24.Name = "Label24"
		Me.Label19.Text = "Sem:"
		Me.Label19.Size = New System.Drawing.Size(33, 17)
		Me.Label19.Location = New System.Drawing.Point(312, 112)
		Me.Label19.TabIndex = 65
		Me.Label19.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label19.BackColor = System.Drawing.SystemColors.Control
		Me.Label19.Enabled = True
		Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label19.UseMnemonic = True
		Me.Label19.Visible = True
		Me.Label19.AutoSize = False
		Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label19.Name = "Label19"
		Me.Label18.Text = "Hasta:"
		Me.Label18.Size = New System.Drawing.Size(57, 16)
		Me.Label18.Location = New System.Drawing.Point(176, 136)
		Me.Label18.TabIndex = 63
		Me.Label18.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label18.BackColor = System.Drawing.SystemColors.Control
		Me.Label18.Enabled = True
		Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label18.UseMnemonic = True
		Me.Label18.Visible = True
		Me.Label18.AutoSize = False
		Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label18.Name = "Label18"
		Me.Label15.Text = "POST: Desde"
		Me.Label15.Size = New System.Drawing.Size(81, 16)
		Me.Label15.Location = New System.Drawing.Point(8, 136)
		Me.Label15.TabIndex = 62
		Me.Label15.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label15.BackColor = System.Drawing.SystemColors.Control
		Me.Label15.Enabled = True
		Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label15.UseMnemonic = True
		Me.Label15.Visible = True
		Me.Label15.AutoSize = False
		Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label15.Name = "Label15"
		Me.Label14.Text = "Hasta:"
		Me.Label14.Size = New System.Drawing.Size(57, 16)
		Me.Label14.Location = New System.Drawing.Point(176, 112)
		Me.Label14.TabIndex = 59
		Me.Label14.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label14.BackColor = System.Drawing.SystemColors.Control
		Me.Label14.Enabled = True
		Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label14.UseMnemonic = True
		Me.Label14.Visible = True
		Me.Label14.AutoSize = False
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label14.Name = "Label14"
		Me.Label8.Text = "PRE: Desde:"
		Me.Label8.Size = New System.Drawing.Size(81, 16)
		Me.Label8.Location = New System.Drawing.Point(8, 112)
		Me.Label8.TabIndex = 58
		Me.Label8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label8.BackColor = System.Drawing.SystemColors.Control
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label11.Text = "Pre/Post:"
		Me.Label11.Size = New System.Drawing.Size(49, 25)
		Me.Label11.Location = New System.Drawing.Point(8, 56)
		Me.Label11.TabIndex = 55
		Me.Label11.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label11.BackColor = System.Drawing.SystemColors.Control
		Me.Label11.Enabled = True
		Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.lblPrePost.Text = "Label8"
		Me.lblPrePost.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblPrePost.Size = New System.Drawing.Size(297, 17)
		Me.lblPrePost.Location = New System.Drawing.Point(64, 56)
		Me.lblPrePost.TabIndex = 54
		Me.lblPrePost.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblPrePost.BackColor = System.Drawing.SystemColors.Control
		Me.lblPrePost.Enabled = True
		Me.lblPrePost.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblPrePost.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblPrePost.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblPrePost.UseMnemonic = True
		Me.lblPrePost.Visible = True
		Me.lblPrePost.AutoSize = False
		Me.lblPrePost.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblPrePost.Name = "lblPrePost"
		Me.Label21.Text = "Metodo:"
		Me.Label21.Size = New System.Drawing.Size(49, 16)
		Me.Label21.Location = New System.Drawing.Point(152, 24)
		Me.Label21.TabIndex = 53
		Me.Label21.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label21.BackColor = System.Drawing.SystemColors.Control
		Me.Label21.Enabled = True
		Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label21.UseMnemonic = True
		Me.Label21.Visible = True
		Me.Label21.AutoSize = False
		Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label21.Name = "Label21"
		Me.Label20.Text = "A�o:"
		Me.Label20.Size = New System.Drawing.Size(33, 16)
		Me.Label20.Location = New System.Drawing.Point(16, 24)
		Me.Label20.TabIndex = 51
		Me.Label20.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label20.BackColor = System.Drawing.SystemColors.Control
		Me.Label20.Enabled = True
		Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label20.UseMnemonic = True
		Me.Label20.Visible = True
		Me.Label20.AutoSize = False
		Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label20.Name = "Label20"
		Me.Frame5.Text = "2do Paso POST"
		Me.Frame5.Size = New System.Drawing.Size(393, 89)
		Me.Frame5.Location = New System.Drawing.Point(0, 208)
		Me.Frame5.TabIndex = 37
		Me.Frame5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame5.BackColor = System.Drawing.SystemColors.Control
		Me.Frame5.Enabled = True
		Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame5.Visible = True
		Me.Frame5.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame5.Name = "Frame5"
		Me.cmdPrint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdPrint.Text = "Imprimir"
		Me.cmdPrint.Size = New System.Drawing.Size(76, 26)
		Me.cmdPrint.Location = New System.Drawing.Point(96, 48)
		Me.cmdPrint.TabIndex = 76
		Me.cmdPrint.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
		Me.cmdPrint.CausesValidation = True
		Me.cmdPrint.Enabled = True
		Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdPrint.TabStop = True
		Me.cmdPrint.Name = "cmdPrint"
		Me.Command14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command14.Text = "Pre Sync"
		Me.Command14.Size = New System.Drawing.Size(76, 23)
		Me.Command14.Location = New System.Drawing.Point(40, 16)
		Me.Command14.TabIndex = 41
		Me.Command14.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command14.BackColor = System.Drawing.SystemColors.Control
		Me.Command14.CausesValidation = True
		Me.Command14.Enabled = True
		Me.Command14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command14.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command14.TabStop = True
		Me.Command14.Name = "Command14"
		Me.Command13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command13.Text = "Post Sync"
		Me.Command13.Size = New System.Drawing.Size(76, 23)
		Me.Command13.Location = New System.Drawing.Point(144, 16)
		Me.Command13.TabIndex = 38
		Me.Command13.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command13.BackColor = System.Drawing.SystemColors.Control
		Me.Command13.CausesValidation = True
		Me.Command13.Enabled = True
		Me.Command13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command13.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command13.TabStop = True
		Me.Command13.Name = "Command13"
		Me.lblStatus2.BackColor = System.Drawing.Color.Transparent
		Me.lblStatus2.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblStatus2.ForeColor = System.Drawing.SystemColors.Highlight
		Me.lblStatus2.Size = New System.Drawing.Size(156, 16)
		Me.lblStatus2.Location = New System.Drawing.Point(232, 24)
		Me.lblStatus2.TabIndex = 42
		Me.lblStatus2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblStatus2.Enabled = True
		Me.lblStatus2.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblStatus2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblStatus2.UseMnemonic = True
		Me.lblStatus2.Visible = True
		Me.lblStatus2.AutoSize = False
		Me.lblStatus2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.lblStatus2.Name = "lblStatus2"
        'Me.frmPrePost_Renamed.Text = "Pre/Post por NOMBRE (TITULO1 ONLY)"
        'Me.frmPrePost_Renamed.Enabled = False
        'Me.frmPrePost_Renamed.Size = New System.Drawing.Size(441, 461)
        'Me.frmPrePost_Renamed.Location = New System.Drawing.Point(448, 8)
        'Me.frmPrePost_Renamed.TabIndex = 0
        'Me.frmPrePost_Renamed.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        'Me.frmPrePost_Renamed.BackColor = System.Drawing.SystemColors.Control
        'Me.frmPrePost_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
        'Me.frmPrePost_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        'Me.frmPrePost_Renamed.Visible = True
        'Me.frmPrePost_Renamed.Padding = New System.Windows.Forms.Padding(0)
        'Me.frmPrePost_Renamed.Name = "frmPrePost_Renamed"
		Me.Frame4.Text = "2do Paso POST"
		Me.Frame4.Size = New System.Drawing.Size(393, 57)
		Me.Frame4.Location = New System.Drawing.Point(24, 80)
		Me.Frame4.TabIndex = 31
		Me.Frame4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame4.BackColor = System.Drawing.SystemColors.Control
		Me.Frame4.Enabled = True
		Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame4.Visible = True
		Me.Frame4.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame4.Name = "Frame4"
		Me.txtSemPost.AutoSize = False
		Me.txtSemPost.Size = New System.Drawing.Size(41, 19)
		Me.txtSemPost.Location = New System.Drawing.Point(184, 24)
		Me.txtSemPost.TabIndex = 35
		Me.txtSemPost.Text = "2"
		Me.txtSemPost.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtSemPost.AcceptsReturn = True
		Me.txtSemPost.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtSemPost.BackColor = System.Drawing.SystemColors.Window
		Me.txtSemPost.CausesValidation = True
		Me.txtSemPost.Enabled = True
		Me.txtSemPost.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtSemPost.HideSelection = True
		Me.txtSemPost.ReadOnly = False
		Me.txtSemPost.Maxlength = 0
		Me.txtSemPost.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtSemPost.MultiLine = False
		Me.txtSemPost.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtSemPost.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtSemPost.TabStop = True
		Me.txtSemPost.Visible = True
		Me.txtSemPost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtSemPost.Name = "txtSemPost"
		Me.txtyearPost.AutoSize = False
		Me.txtyearPost.Size = New System.Drawing.Size(79, 19)
		Me.txtyearPost.Location = New System.Drawing.Point(56, 24)
		Me.txtyearPost.TabIndex = 33
		Me.txtyearPost.Text = "2009"
		Me.txtyearPost.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtyearPost.AcceptsReturn = True
		Me.txtyearPost.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtyearPost.BackColor = System.Drawing.SystemColors.Window
		Me.txtyearPost.CausesValidation = True
		Me.txtyearPost.Enabled = True
		Me.txtyearPost.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtyearPost.HideSelection = True
		Me.txtyearPost.ReadOnly = False
		Me.txtyearPost.Maxlength = 0
		Me.txtyearPost.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtyearPost.MultiLine = False
		Me.txtyearPost.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtyearPost.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtyearPost.TabStop = True
		Me.txtyearPost.Visible = True
		Me.txtyearPost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtyearPost.Name = "txtyearPost"
		Me.Command4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command4.Text = "Post Sync"
		Me.Command4.Size = New System.Drawing.Size(76, 23)
		Me.Command4.Location = New System.Drawing.Point(248, 16)
		Me.Command4.TabIndex = 32
		Me.Command4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command4.BackColor = System.Drawing.SystemColors.Control
		Me.Command4.CausesValidation = True
		Me.Command4.Enabled = True
		Me.Command4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command4.TabStop = True
		Me.Command4.Name = "Command4"
		Me.Label13.Text = "Sem:"
		Me.Label13.Size = New System.Drawing.Size(33, 17)
		Me.Label13.Location = New System.Drawing.Point(148, 24)
		Me.Label13.TabIndex = 36
		Me.Label13.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label13.BackColor = System.Drawing.SystemColors.Control
		Me.Label13.Enabled = True
		Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label13.UseMnemonic = True
		Me.Label13.Visible = True
		Me.Label13.AutoSize = False
		Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label13.Name = "Label13"
		Me.Label12.Text = "A�o:"
		Me.Label12.Size = New System.Drawing.Size(34, 16)
		Me.Label12.Location = New System.Drawing.Point(8, 25)
		Me.Label12.TabIndex = 34
		Me.Label12.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label12.BackColor = System.Drawing.SystemColors.Control
		Me.Label12.Enabled = True
		Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label12.UseMnemonic = True
		Me.Label12.Visible = True
		Me.Label12.AutoSize = False
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label12.Name = "Label12"
		Me.Frame3.Text = "1er Paso: PRE"
		Me.Frame3.Size = New System.Drawing.Size(393, 57)
		Me.Frame3.Location = New System.Drawing.Point(24, 16)
		Me.Frame3.TabIndex = 25
		Me.Frame3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame3.BackColor = System.Drawing.SystemColors.Control
		Me.Frame3.Enabled = True
		Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame3.Visible = True
		Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame3.Name = "Frame3"
		Me.txtSemPRE.AutoSize = False
		Me.txtSemPRE.Size = New System.Drawing.Size(41, 19)
		Me.txtSemPRE.Location = New System.Drawing.Point(184, 24)
		Me.txtSemPRE.TabIndex = 29
		Me.txtSemPRE.Text = "1"
		Me.txtSemPRE.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtSemPRE.AcceptsReturn = True
		Me.txtSemPRE.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtSemPRE.BackColor = System.Drawing.SystemColors.Window
		Me.txtSemPRE.CausesValidation = True
		Me.txtSemPRE.Enabled = True
		Me.txtSemPRE.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtSemPRE.HideSelection = True
		Me.txtSemPRE.ReadOnly = False
		Me.txtSemPRE.Maxlength = 0
		Me.txtSemPRE.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtSemPRE.MultiLine = False
		Me.txtSemPRE.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtSemPRE.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtSemPRE.TabStop = True
		Me.txtSemPRE.Visible = True
		Me.txtSemPRE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtSemPRE.Name = "txtSemPRE"
		Me.txtYearPRE.AutoSize = False
		Me.txtYearPRE.Size = New System.Drawing.Size(79, 19)
		Me.txtYearPRE.Location = New System.Drawing.Point(56, 24)
		Me.txtYearPRE.TabIndex = 27
		Me.txtYearPRE.Text = "2009"
		Me.txtYearPRE.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtYearPRE.AcceptsReturn = True
		Me.txtYearPRE.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtYearPRE.BackColor = System.Drawing.SystemColors.Window
		Me.txtYearPRE.CausesValidation = True
		Me.txtYearPRE.Enabled = True
		Me.txtYearPRE.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtYearPRE.HideSelection = True
		Me.txtYearPRE.ReadOnly = False
		Me.txtYearPRE.Maxlength = 0
		Me.txtYearPRE.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtYearPRE.MultiLine = False
		Me.txtYearPRE.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtYearPRE.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtYearPRE.TabStop = True
		Me.txtYearPRE.Visible = True
		Me.txtYearPRE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtYearPRE.Name = "txtYearPRE"
		Me.Command2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command2.Text = "Pre Sync"
		Me.Command2.Size = New System.Drawing.Size(76, 23)
		Me.Command2.Location = New System.Drawing.Point(248, 23)
		Me.Command2.TabIndex = 26
		Me.Command2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command2.BackColor = System.Drawing.SystemColors.Control
		Me.Command2.CausesValidation = True
		Me.Command2.Enabled = True
		Me.Command2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command2.TabStop = True
		Me.Command2.Name = "Command2"
		Me.Label9.Text = "Sem:"
		Me.Label9.Size = New System.Drawing.Size(33, 17)
		Me.Label9.Location = New System.Drawing.Point(144, 24)
		Me.Label9.TabIndex = 30
		Me.Label9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label9.BackColor = System.Drawing.SystemColors.Control
		Me.Label9.Enabled = True
		Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label9.UseMnemonic = True
		Me.Label9.Visible = True
		Me.Label9.AutoSize = False
		Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label9.Name = "Label9"
		Me.Label5.Text = "A�o:"
		Me.Label5.Size = New System.Drawing.Size(34, 16)
		Me.Label5.Location = New System.Drawing.Point(24, 24)
		Me.Label5.TabIndex = 28
		Me.Label5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label5.BackColor = System.Drawing.SystemColors.Control
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Frame2.Text = "Total Datos Procesados:"
		Me.Frame2.Size = New System.Drawing.Size(391, 76)
		Me.Frame2.Location = New System.Drawing.Point(24, 176)
		Me.Frame2.TabIndex = 6
		Me.Frame2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame2.BackColor = System.Drawing.SystemColors.Control
		Me.Frame2.Enabled = True
		Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame2.Visible = True
		Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame2.Name = "Frame2"
		Me.txtDatosDup.AutoSize = False
		Me.txtDatosDup.Size = New System.Drawing.Size(51, 21)
		Me.txtDatosDup.Location = New System.Drawing.Point(175, 40)
		Me.txtDatosDup.ReadOnly = True
		Me.txtDatosDup.TabIndex = 14
		Me.txtDatosDup.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDatosDup.AcceptsReturn = True
		Me.txtDatosDup.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDatosDup.BackColor = System.Drawing.SystemColors.Window
		Me.txtDatosDup.CausesValidation = True
		Me.txtDatosDup.Enabled = True
		Me.txtDatosDup.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDatosDup.HideSelection = True
		Me.txtDatosDup.Maxlength = 0
		Me.txtDatosDup.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDatosDup.MultiLine = False
		Me.txtDatosDup.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDatosDup.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDatosDup.TabStop = True
		Me.txtDatosDup.Visible = True
		Me.txtDatosDup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtDatosDup.Name = "txtDatosDup"
		Me.txtDatosNoMatch.AutoSize = False
		Me.txtDatosNoMatch.Size = New System.Drawing.Size(51, 21)
		Me.txtDatosNoMatch.Location = New System.Drawing.Point(175, 15)
		Me.txtDatosNoMatch.ReadOnly = True
		Me.txtDatosNoMatch.TabIndex = 12
		Me.txtDatosNoMatch.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDatosNoMatch.AcceptsReturn = True
		Me.txtDatosNoMatch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDatosNoMatch.BackColor = System.Drawing.SystemColors.Window
		Me.txtDatosNoMatch.CausesValidation = True
		Me.txtDatosNoMatch.Enabled = True
		Me.txtDatosNoMatch.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDatosNoMatch.HideSelection = True
		Me.txtDatosNoMatch.Maxlength = 0
		Me.txtDatosNoMatch.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDatosNoMatch.MultiLine = False
		Me.txtDatosNoMatch.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDatosNoMatch.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDatosNoMatch.TabStop = True
		Me.txtDatosNoMatch.Visible = True
		Me.txtDatosNoMatch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtDatosNoMatch.Name = "txtDatosNoMatch"
		Me.txtDatosPost.AutoSize = False
		Me.txtDatosPost.Size = New System.Drawing.Size(51, 21)
		Me.txtDatosPost.Location = New System.Drawing.Point(60, 40)
		Me.txtDatosPost.ReadOnly = True
		Me.txtDatosPost.TabIndex = 10
		Me.txtDatosPost.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDatosPost.AcceptsReturn = True
		Me.txtDatosPost.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDatosPost.BackColor = System.Drawing.SystemColors.Window
		Me.txtDatosPost.CausesValidation = True
		Me.txtDatosPost.Enabled = True
		Me.txtDatosPost.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDatosPost.HideSelection = True
		Me.txtDatosPost.Maxlength = 0
		Me.txtDatosPost.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDatosPost.MultiLine = False
		Me.txtDatosPost.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDatosPost.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDatosPost.TabStop = True
		Me.txtDatosPost.Visible = True
		Me.txtDatosPost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtDatosPost.Name = "txtDatosPost"
		Me.txtDatosPre.AutoSize = False
		Me.txtDatosPre.Size = New System.Drawing.Size(51, 21)
		Me.txtDatosPre.Location = New System.Drawing.Point(60, 15)
		Me.txtDatosPre.ReadOnly = True
		Me.txtDatosPre.TabIndex = 8
		Me.txtDatosPre.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDatosPre.AcceptsReturn = True
		Me.txtDatosPre.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDatosPre.BackColor = System.Drawing.SystemColors.Window
		Me.txtDatosPre.CausesValidation = True
		Me.txtDatosPre.Enabled = True
		Me.txtDatosPre.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDatosPre.HideSelection = True
		Me.txtDatosPre.Maxlength = 0
		Me.txtDatosPre.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDatosPre.MultiLine = False
		Me.txtDatosPre.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDatosPre.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDatosPre.TabStop = True
		Me.txtDatosPre.Visible = True
		Me.txtDatosPre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtDatosPre.Name = "txtDatosPre"
		Me.Label7.Text = "Duplicados:"
		Me.Label7.Size = New System.Drawing.Size(61, 21)
		Me.Label7.Location = New System.Drawing.Point(115, 45)
		Me.Label7.TabIndex = 13
		Me.Label7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label7.BackColor = System.Drawing.SystemColors.Control
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Label6.Text = "No Match:"
		Me.Label6.Size = New System.Drawing.Size(61, 21)
		Me.Label6.Location = New System.Drawing.Point(115, 20)
		Me.Label6.TabIndex = 11
		Me.Label6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label6.BackColor = System.Drawing.SystemColors.Control
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Label4.Text = "# Est. Post:"
		Me.Label4.Size = New System.Drawing.Size(61, 21)
		Me.Label4.Location = New System.Drawing.Point(5, 40)
		Me.Label4.TabIndex = 9
		Me.Label4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label4.BackColor = System.Drawing.SystemColors.Control
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label3.Text = "# Est. Pre:"
		Me.Label3.Size = New System.Drawing.Size(61, 21)
		Me.Label3.Location = New System.Drawing.Point(5, 20)
		Me.Label3.TabIndex = 7
		Me.Label3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Frame1.Text = "Informes para Colegios:"
		Me.Frame1.Size = New System.Drawing.Size(389, 156)
		Me.Frame1.Location = New System.Drawing.Point(24, 264)
		Me.Frame1.TabIndex = 2
		Me.Frame1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame1.BackColor = System.Drawing.SystemColors.Control
		Me.Frame1.Enabled = True
		Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame1.Visible = True
		Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame1.Name = "Frame1"
		Me.cboSchools.Size = New System.Drawing.Size(209, 21)
		Me.cboSchools.Location = New System.Drawing.Point(108, 24)
		Me.cboSchools.TabIndex = 72
		Me.cboSchools.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboSchools.BackColor = System.Drawing.SystemColors.Window
		Me.cboSchools.CausesValidation = True
		Me.cboSchools.Enabled = True
		Me.cboSchools.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cboSchools.IntegralHeight = True
		Me.cboSchools.Cursor = System.Windows.Forms.Cursors.Default
		Me.cboSchools.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cboSchools.Sorted = False
		Me.cboSchools.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cboSchools.TabStop = True
		Me.cboSchools.Visible = True
		Me.cboSchools.Name = "cboSchools"
		Me.Command12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command12.Text = "Reg AID"
		Me.Command12.Size = New System.Drawing.Size(66, 26)
		Me.Command12.Location = New System.Drawing.Point(85, 115)
		Me.Command12.TabIndex = 23
		Me.Command12.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command12.BackColor = System.Drawing.SystemColors.Control
		Me.Command12.CausesValidation = True
		Me.Command12.Enabled = True
		Me.Command12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command12.TabStop = True
		Me.Command12.Name = "Command12"
		Me.Command11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command11.Text = "Pre1 LES"
		Me.Command11.Size = New System.Drawing.Size(66, 26)
		Me.Command11.Location = New System.Drawing.Point(85, 85)
		Me.Command11.TabIndex = 22
		Me.Command11.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command11.BackColor = System.Drawing.SystemColors.Control
		Me.Command11.CausesValidation = True
		Me.Command11.Enabled = True
		Me.Command11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command11.TabStop = True
		Me.Command11.Name = "Command11"
		Me.Command10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command10.Text = "Pre1 MAT"
		Me.Command10.Size = New System.Drawing.Size(66, 26)
		Me.Command10.Location = New System.Drawing.Point(155, 85)
		Me.Command10.TabIndex = 21
		Me.Command10.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command10.BackColor = System.Drawing.SystemColors.Control
		Me.Command10.CausesValidation = True
		Me.Command10.Enabled = True
		Me.Command10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command10.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command10.TabStop = True
		Me.Command10.Name = "Command10"
		Me.Command9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command9.Text = "Pre1 REN"
		Me.Command9.Size = New System.Drawing.Size(66, 26)
		Me.Command9.Location = New System.Drawing.Point(225, 85)
		Me.Command9.TabIndex = 20
		Me.Command9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command9.BackColor = System.Drawing.SystemColors.Control
		Me.Command9.CausesValidation = True
		Me.Command9.Enabled = True
		Me.Command9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command9.TabStop = True
		Me.Command9.Name = "Command9"
		Me.Command8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command8.Text = "Indiv AID"
		Me.Command8.Size = New System.Drawing.Size(76, 26)
		Me.Command8.Location = New System.Drawing.Point(5, 115)
		Me.Command8.TabIndex = 19
		Me.Command8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command8.BackColor = System.Drawing.SystemColors.Control
		Me.Command8.CausesValidation = True
		Me.Command8.Enabled = True
		Me.Command8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command8.TabStop = True
		Me.Command8.Name = "Command8"
		Me.Command7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command7.Text = "Indiv. Pre1"
		Me.Command7.Size = New System.Drawing.Size(76, 26)
		Me.Command7.Location = New System.Drawing.Point(5, 85)
		Me.Command7.TabIndex = 18
		Me.Command7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command7.BackColor = System.Drawing.SystemColors.Control
		Me.Command7.CausesValidation = True
		Me.Command7.Enabled = True
		Me.Command7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command7.TabStop = True
		Me.Command7.Name = "Command7"
		Me.Command6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command6.Text = "Dest. REN"
		Me.Command6.Size = New System.Drawing.Size(66, 26)
		Me.Command6.Location = New System.Drawing.Point(225, 55)
		Me.Command6.TabIndex = 17
		Me.Command6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command6.BackColor = System.Drawing.SystemColors.Control
		Me.Command6.CausesValidation = True
		Me.Command6.Enabled = True
		Me.Command6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command6.TabStop = True
		Me.Command6.Name = "Command6"
		Me.Command5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command5.Text = "Dest. MAT"
		Me.Command5.Size = New System.Drawing.Size(66, 26)
		Me.Command5.Location = New System.Drawing.Point(155, 55)
		Me.Command5.TabIndex = 16
		Me.Command5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command5.BackColor = System.Drawing.SystemColors.Control
		Me.Command5.CausesValidation = True
		Me.Command5.Enabled = True
		Me.Command5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command5.TabStop = True
		Me.Command5.Name = "Command5"
		Me.Command3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command3.Text = "Dest. LES"
		Me.Command3.Size = New System.Drawing.Size(66, 26)
		Me.Command3.Location = New System.Drawing.Point(85, 55)
		Me.Command3.TabIndex = 5
		Me.Command3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command3.BackColor = System.Drawing.SystemColors.Control
		Me.Command3.CausesValidation = True
		Me.Command3.Enabled = True
		Me.Command3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command3.TabStop = True
		Me.Command3.Name = "Command3"
		Me.Command1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command1.Text = "Individual"
		Me.Command1.Size = New System.Drawing.Size(76, 26)
		Me.Command1.Location = New System.Drawing.Point(5, 55)
		Me.Command1.TabIndex = 4
		Me.Command1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Command1.BackColor = System.Drawing.SystemColors.Control
		Me.Command1.CausesValidation = True
		Me.Command1.Enabled = True
		Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command1.TabStop = True
		Me.Command1.Name = "Command1"
		Me.Label2.Text = "Seleccione Colegio:"
		Me.Label2.Size = New System.Drawing.Size(106, 16)
		Me.Label2.Location = New System.Drawing.Point(8, 24)
		Me.Label2.TabIndex = 73
		Me.Label2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdClose.Text = "Close"
		Me.cmdClose.Size = New System.Drawing.Size(64, 28)
		Me.cmdClose.Location = New System.Drawing.Point(368, 424)
		Me.cmdClose.TabIndex = 1
		Me.cmdClose.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
		Me.cmdClose.CausesValidation = True
		Me.cmdClose.Enabled = True
		Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdClose.TabStop = True
		Me.cmdClose.Name = "cmdClose"
		Me.Label10.Size = New System.Drawing.Size(66, 16)
		Me.Label10.Location = New System.Drawing.Point(24, 120)
		Me.Label10.TabIndex = 24
		Me.Label10.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label10.BackColor = System.Drawing.SystemColors.Control
		Me.Label10.Enabled = True
		Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label10.UseMnemonic = True
		Me.Label10.Visible = True
		Me.Label10.AutoSize = False
		Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label10.Name = "Label10"
		Me.lblStatus.BackColor = System.Drawing.Color.Transparent
		Me.lblStatus.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblStatus.ForeColor = System.Drawing.SystemColors.Highlight
		Me.lblStatus.Size = New System.Drawing.Size(156, 16)
		Me.lblStatus.Location = New System.Drawing.Point(128, 144)
		Me.lblStatus.TabIndex = 15
		Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblStatus.Enabled = True
		Me.lblStatus.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblStatus.UseMnemonic = True
		Me.lblStatus.Visible = True
		Me.lblStatus.AutoSize = False
		Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.lblStatus.Name = "lblStatus"
		Me.Label1.Text = "1er Paso:"
		Me.Label1.Size = New System.Drawing.Size(66, 16)
		Me.Label1.Location = New System.Drawing.Point(24, 48)
		Me.Label1.TabIndex = 3
		Me.Label1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label1.BackColor = System.Drawing.SystemColors.Control
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label17.Text = "PRE/POST POR MATERIA"
		Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label17.Size = New System.Drawing.Size(409, 17)
		Me.Label17.Location = New System.Drawing.Point(0, 8)
		Me.Label17.TabIndex = 40
		Me.Label17.BackColor = System.Drawing.SystemColors.Control
		Me.Label17.Enabled = True
		Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label17.UseMnemonic = True
		Me.Label17.Visible = True
		Me.Label17.AutoSize = False
		Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label17.Name = "Label17"
		Me.Controls.Add(Frame7)
		Me.Controls.Add(Frame6)
		Me.Controls.Add(Frame5)
		Me.Controls.Add(frmPrePost)
		Me.Controls.Add(Label17)
		Me.Frame7.Controls.Add(Command15)
		Me.Frame7.Controls.Add(TxtNV)
		Me.Frame7.Controls.Add(txtRen)
		Me.Frame7.Controls.Add(txtLes)
		Me.Frame7.Controls.Add(txtEstPre)
		Me.Frame7.Controls.Add(txtMat)
		Me.Frame7.Controls.Add(Label26)
		Me.Frame7.Controls.Add(Label25)
		Me.Frame7.Controls.Add(Label16)
		Me.Frame7.Controls.Add(Label23)
		Me.Frame7.Controls.Add(Label22)
		Me.Frame6.Controls.Add(cboSchools2)
		Me.Frame6.Controls.Add(txtPOSTSem)
		Me.Frame6.Controls.Add(txtPREsem)
		Me.Frame6.Controls.Add(txtPOSTHasta)
		Me.Frame6.Controls.Add(txtPOSTDesde)
		Me.Frame6.Controls.Add(txtPREHasta)
		Me.Frame6.Controls.Add(txtPREDesde)
		Me.Frame6.Controls.Add(cboMetodo)
		Me.Frame6.Controls.Add(cboYear)
		Me.Frame6.Controls.Add(Label27)
		Me.Frame6.Controls.Add(Label24)
		Me.Frame6.Controls.Add(Label19)
		Me.Frame6.Controls.Add(Label18)
		Me.Frame6.Controls.Add(Label15)
		Me.Frame6.Controls.Add(Label14)
		Me.Frame6.Controls.Add(Label8)
		Me.Frame6.Controls.Add(Label11)
		Me.Frame6.Controls.Add(lblPrePost)
		Me.Frame6.Controls.Add(Label21)
		Me.Frame6.Controls.Add(Label20)
		Me.Frame5.Controls.Add(cmdPrint)
		Me.Frame5.Controls.Add(Command14)
		Me.Frame5.Controls.Add(Command13)
		Me.Frame5.Controls.Add(lblStatus2)
		Me.frmPrePost.Controls.Add(Frame4)
		Me.frmPrePost.Controls.Add(Frame3)
		Me.frmPrePost.Controls.Add(Frame2)
		Me.frmPrePost.Controls.Add(Frame1)
		Me.frmPrePost.Controls.Add(cmdClose)
		Me.frmPrePost.Controls.Add(Label10)
		Me.frmPrePost.Controls.Add(lblStatus)
		Me.frmPrePost.Controls.Add(Label1)
		Me.Frame4.Controls.Add(txtSemPost)
		Me.Frame4.Controls.Add(txtyearPost)
		Me.Frame4.Controls.Add(Command4)
		Me.Frame4.Controls.Add(Label13)
		Me.Frame4.Controls.Add(Label12)
		Me.Frame3.Controls.Add(txtSemPRE)
		Me.Frame3.Controls.Add(txtYearPRE)
		Me.Frame3.Controls.Add(Command2)
		Me.Frame3.Controls.Add(Label9)
		Me.Frame3.Controls.Add(Label5)
		Me.Frame2.Controls.Add(txtDatosDup)
		Me.Frame2.Controls.Add(txtDatosNoMatch)
		Me.Frame2.Controls.Add(txtDatosPost)
		Me.Frame2.Controls.Add(txtDatosPre)
		Me.Frame2.Controls.Add(Label7)
		Me.Frame2.Controls.Add(Label6)
		Me.Frame2.Controls.Add(Label4)
		Me.Frame2.Controls.Add(Label3)
		Me.Frame1.Controls.Add(cboSchools)
		Me.Frame1.Controls.Add(Command12)
		Me.Frame1.Controls.Add(Command11)
		Me.Frame1.Controls.Add(Command10)
		Me.Frame1.Controls.Add(Command9)
		Me.Frame1.Controls.Add(Command8)
		Me.Frame1.Controls.Add(Command7)
		Me.Frame1.Controls.Add(Command6)
		Me.Frame1.Controls.Add(Command5)
		Me.Frame1.Controls.Add(Command3)
		Me.Frame1.Controls.Add(Command1)
		Me.Frame1.Controls.Add(Label2)
		Me.Frame7.ResumeLayout(False)
		Me.Frame6.ResumeLayout(False)
		Me.Frame5.ResumeLayout(False)
        'Me.frmPrePost_Renamed.ResumeLayout(False)
		Me.Frame4.ResumeLayout(False)
		Me.Frame3.ResumeLayout(False)
		Me.Frame2.ResumeLayout(False)
		Me.Frame1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class