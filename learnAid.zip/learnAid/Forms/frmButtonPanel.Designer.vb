<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmButtonPanel
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents ImgMenuBar32 As System.Windows.Forms.ImageList
	Public WithEvents ImageList1 As System.Windows.Forms.ImageList
    Public WithEvents ButtonsPanel As Axmccommandv102.Axmcbarmenu
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmButtonPanel))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ImgMenuBar32 = New System.Windows.Forms.ImageList
		Me.ImageList1 = New System.Windows.Forms.ImageList
        'Me.ButtonsPanel = New Axmccommandv102.Axmcbarmenu
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
        'CType(Me.ButtonsPanel, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Text = "Form1"
		Me.ClientSize = New System.Drawing.Size(133, 465)
		Me.Location = New System.Drawing.Point(0, 0)
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmButtonPanel"
		Me.ImgMenuBar32.ImageSize = New System.Drawing.Size(32, 32)
		Me.ImgMenuBar32.TransparentColor = System.Drawing.Color.FromARGB(192, 192, 192)
		Me.ImgMenuBar32.ImageStream = CType(resources.GetObject("ImgMenuBar32.ImageStream"), System.Windows.Forms.ImageListStreamer)
		Me.ImgMenuBar32.Images.SetKeyName(0, "Reports")
		Me.ImgMenuBar32.Images.SetKeyName(1, "Accounting")
		Me.ImgMenuBar32.Images.SetKeyName(2, "Evaluations")
		Me.ImageList1.TransparentColor = System.Drawing.Color.FromARGB(192, 192, 192)
        'ButtonsPanel.OcxState = CType(resources.GetObject("ButtonsPanel.OcxState"), System.Windows.Forms.AxHost.State)
        'Me.ButtonsPanel.Size = New System.Drawing.Size(105, 465)
        'Me.ButtonsPanel.Location = New System.Drawing.Point(0, 0)
        'Me.ButtonsPanel.TabIndex = 0
        'Me.ButtonsPanel.Name = "ButtonsPanel"
        'Me.Controls.Add(ButtonsPanel)
        'CType(Me.ButtonsPanel, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class