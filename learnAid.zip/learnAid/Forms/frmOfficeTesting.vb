Option Strict Off
Option Explicit On
Friend Class frmOfficeTesting
	Inherits System.Windows.Forms.Form
End Class